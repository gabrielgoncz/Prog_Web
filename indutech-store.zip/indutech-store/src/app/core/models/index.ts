// =====================================================
// INDUTECH STORE - CORE MODELS
// Interfaces TypeScript para toda a aplicação
// =====================================================

/** Produto */
export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  price: number;
  originalPrice?: number;         // Preço antes do desconto
  discount?: number;              // Percentual de desconto
  images: string[];
  thumbnail: string;
  category: Category;
  brand: string;
  sku: string;
  stock: number;
  rating: number;
  reviewCount: number;
  specifications: Specification[];
  tags: string[];
  isFeatured: boolean;
  isNew: boolean;
  isOnSale: boolean;
  weight?: number;                // em kg
  dimensions?: Dimensions;
  createdAt: Date;
}

export interface Specification {
  key: string;
  value: string;
}

export interface Dimensions {
  width: number;   // cm
  height: number;
  depth: number;
}

/** Categoria */
export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  description?: string;
  productCount?: number;
  parent?: string;
}

/** Item do carrinho */
export interface CartItem {
  product: Product;
  quantity: number;
}

/** Carrinho */
export interface Cart {
  items: CartItem[];
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  couponCode?: string;
}

/** Usuário */
export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  cpf?: string;
  cnpj?: string;
  addresses: Address[];
  role: 'customer' | 'admin';
  createdAt: Date;
  favorites: string[];           // IDs de produtos
}

/** Endereço */
export interface Address {
  id: string;
  label: string;                 // 'Casa', 'Empresa', etc.
  street: string;
  number: string;
  complement?: string;
  neighborhood: string;
  city: string;
  state: string;
  zipCode: string;
  isDefault: boolean;
}

/** Pedido */
export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  status: OrderStatus;
  address: Address;
  payment: PaymentInfo;
  subtotal: number;
  shipping: number;
  discount: number;
  total: number;
  tracking?: string;
  createdAt: Date;
  updatedAt: Date;
}

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

/** Pagamento */
export interface PaymentInfo {
  method: PaymentMethod;
  status: 'pending' | 'approved' | 'rejected';
  installments?: number;
  last4Digits?: string;
  pixCode?: string;
  boletoCode?: string;
  transactionId?: string;
}

export type PaymentMethod = 'credit_card' | 'debit_card' | 'pix' | 'boleto';

/** Filtros de catálogo */
export interface ProductFilters {
  search?: string;
  categoryId?: string;
  brands?: string[];
  minPrice?: number;
  maxPrice?: number;
  inStock?: boolean;
  onSale?: boolean;
  rating?: number;
  sortBy?: SortOption;
}

export type SortOption =
  | 'relevance'
  | 'price_asc'
  | 'price_desc'
  | 'name_asc'
  | 'rating'
  | 'newest';

/** Avaliação */
export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  title: string;
  comment: string;
  createdAt: Date;
  verified: boolean;
}

/** Frete */
export interface ShippingOption {
  carrier: string;
  service: string;
  price: number;
  days: number;
  logo?: string;
}

/** Resposta paginada */
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

/** Credenciais de login */
export interface LoginCredentials {
  email: string;
  password: string;
}

/** Dados de cadastro */
export interface RegisterData {
  name: string;
  email: string;
  password: string;
  phone?: string;
  cpf?: string;
}

/** Dados de checkout */
export interface CheckoutData {
  address: Address;
  shipping: ShippingOption;
  payment: {
    method: PaymentMethod;
    cardNumber?: string;
    cardName?: string;
    cardExpiry?: string;
    cardCvv?: string;
    installments?: number;
    cpf?: string;
  };
}
