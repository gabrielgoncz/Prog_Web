import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MockDataService } from '../../../core/services/mock-data.service';
import { ToastService } from '../../../core/services/toast.service';
import { Product } from '../../../core/models';

@Component({
  selector: 'app-admin-products',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
<div class="admin-products-page">
  <div class="container">
    <div class="page-header">
      <div>
        <a routerLink="/admin" class="back-link">← Painel Admin</a>
        <h1>📦 Gerenciar Produtos</h1>
      </div>
      <button class="btn btn-primary" (click)="showForm.set(true)">+ Novo Produto</button>
    </div>

    <!-- PRODUCT LIST -->
    <div class="products-table" *ngIf="!showForm()">
      <div class="table-header">
        <span>Produto</span><span>Categoria</span><span>Preço</span><span>Estoque</span><span>Status</span><span>Ações</span>
      </div>
      <div class="table-row" *ngFor="let p of products()">
        <div class="table-row__product">
          <img [src]="p.thumbnail" [alt]="p.name" class="table-img"/>
          <div>
            <strong class="text-sm">{{ p.name | slice:0:45 }}...</strong>
            <span class="text-muted text-sm">SKU: {{ p.sku }}</span>
          </div>
        </div>
        <span class="text-sm">{{ p.category.name }}</span>
        <span class="price price-sm">{{ fmt(p.price) }}</span>
        <span [class.text-danger]="p.stock < 5" [class.text-success]="p.stock >= 5" class="fw-600 text-sm">{{ p.stock }}</span>
        <div class="status-chips">
          <span class="chip chip-active" *ngIf="p.isFeatured">Destaque</span>
          <span class="chip chip-active" *ngIf="p.isNew">Novo</span>
          <span class="chip chip-active" style="background:var(--danger)" *ngIf="p.isOnSale">Promo</span>
        </div>
        <div class="table-actions">
          <a [routerLink]="['/produto', p.slug]" class="btn btn-ghost btn-sm" target="_blank">👁</a>
          <button class="btn btn-ghost btn-sm text-primary" (click)="editProduct(p)">✏️</button>
        </div>
      </div>
    </div>

    <!-- ADD/EDIT FORM -->
    <div class="product-form-card" *ngIf="showForm()">
      <h2>{{ editingId() ? 'Editar Produto' : 'Novo Produto' }}</h2>
      <div class="form-grid">
        <div class="form-group form-group--full">
          <label class="form-label">Nome do Produto *</label>
          <input class="form-control" type="text" [(ngModel)]="form.name" placeholder="Nome completo do produto"/>
        </div>
        <div class="form-group">
          <label class="form-label">SKU *</label>
          <input class="form-control" type="text" [(ngModel)]="form.sku" placeholder="MARCA-MODELO-REF"/>
        </div>
        <div class="form-group">
          <label class="form-label">Marca</label>
          <input class="form-control" type="text" [(ngModel)]="form.brand" placeholder="Siemens, WEG, etc."/>
        </div>
        <div class="form-group">
          <label class="form-label">Preço (R$) *</label>
          <input class="form-control" type="number" [(ngModel)]="form.price" placeholder="0.00" step="0.01"/>
        </div>
        <div class="form-group">
          <label class="form-label">Preço Original (R$)</label>
          <input class="form-control" type="number" [(ngModel)]="form.originalPrice" placeholder="Preço antes do desconto"/>
        </div>
        <div class="form-group">
          <label class="form-label">Estoque</label>
          <input class="form-control" type="number" [(ngModel)]="form.stock" placeholder="0"/>
        </div>
        <div class="form-group">
          <label class="form-label">Categoria</label>
          <select class="form-control" [(ngModel)]="form.categoryId">
            <option *ngFor="let c of categories" [value]="c.id">{{ c.name }}</option>
          </select>
        </div>
        <div class="form-group form-group--full">
          <label class="form-label">Descrição Curta</label>
          <input class="form-control" type="text" [(ngModel)]="form.shortDescription" placeholder="Descrição em uma linha"/>
        </div>
        <div class="form-group form-group--full">
          <label class="form-label">Descrição Completa</label>
          <textarea class="form-control" [(ngModel)]="form.description" rows="4" placeholder="Descrição detalhada do produto..."></textarea>
        </div>
        <div class="form-group form-group--full">
          <label class="form-label">URL da Imagem Principal</label>
          <input class="form-control" type="url" [(ngModel)]="form.thumbnail" placeholder="https://..."/>
        </div>
        <div class="form-group">
          <div class="checkbox-group">
            <label class="filter-check"><input type="checkbox" [(ngModel)]="form.isFeatured"/><span class="filter-check__box"></span> Produto em Destaque</label>
            <label class="filter-check"><input type="checkbox" [(ngModel)]="form.isNew"/><span class="filter-check__box"></span> Produto Novo</label>
            <label class="filter-check"><input type="checkbox" [(ngModel)]="form.isOnSale"/><span class="filter-check__box"></span> Em Promoção</label>
          </div>
        </div>
      </div>

      <div class="form-actions">
        <button class="btn btn-ghost" (click)="cancelForm()">Cancelar</button>
        <button class="btn btn-primary" (click)="saveProduct()">{{ editingId() ? 'Salvar Alterações' : 'Cadastrar Produto' }}</button>
      </div>
    </div>
  </div>
</div>
  `,
  styles: [`
    .admin-products-page { padding: var(--space-xl) 0; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: var(--space-xl); }
    .back-link { font-size: .85rem; color: var(--primary); margin-bottom: 6px; display: block; }
    .products-table { background: var(--surface); border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); overflow: hidden; }
    .table-header { display: grid; grid-template-columns: 2.5fr 1.2fr .8fr .6fr 1fr .6fr; gap: 12px; padding: 12px 16px; background: var(--gray-50); font-size: .75rem; font-weight: 800; text-transform: uppercase; letter-spacing: .06em; color: var(--text-muted); }
    .table-row { display: grid; grid-template-columns: 2.5fr 1.2fr .8fr .6fr 1fr .6fr; gap: 12px; padding: 14px 16px; align-items: center; border-top: 1px solid var(--gray-100); font-size: .875rem; &:hover { background: var(--gray-50); } &__product { display: flex; align-items: center; gap: 10px; } }
    .table-img { width: 48px; height: 48px; object-fit: cover; border-radius: var(--radius-sm); background: var(--gray-100); flex-shrink: 0; }
    .table-actions { display: flex; gap: 4px; }
    .status-chips { display: flex; flex-wrap: wrap; gap: 4px; }
    .status-chips .chip { font-size: .65rem; padding: 2px 6px; }
    .product-form-card { background: var(--surface); border-radius: var(--radius-xl); padding: var(--space-2xl); box-shadow: var(--shadow-lg); h2 { margin-bottom: var(--space-xl); } }
    .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: var(--space-md); }
    .form-group { margin-bottom: 0; }
    .form-group--full { grid-column: 1 / -1; }
    textarea.form-control { resize: vertical; }
    .checkbox-group { display: flex; flex-direction: column; gap: 10px; }
    .filter-check { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: .875rem; }
    .filter-check input { display: none; }
    .filter-check__box { width: 16px; height: 16px; border-radius: 4px; border: 2px solid var(--gray-300); flex-shrink: 0; transition: all var(--transition-fast); position: relative; }
    .filter-check input:checked + .filter-check__box { background: var(--primary); border-color: var(--primary); &::after { content: '✓'; position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: #fff; font-size: .6rem; font-weight: 900; } }
    .form-actions { display: flex; justify-content: flex-end; gap: 12px; margin-top: var(--space-xl); padding-top: var(--space-lg); border-top: 1px solid var(--gray-100); }
    @media (max-width: 900px) { .table-header, .table-row { grid-template-columns: 1fr 1fr; } .table-header span:nth-child(n+3) { display: none; } }
    @media (max-width: 640px) { .form-grid { grid-template-columns: 1fr; } }
  `]
})
export class AdminProductsComponent {
  private mock  = inject(MockDataService);
  private toast = inject(ToastService);

  products   = signal(this.mock.getProducts());
  categories = this.mock.getCategories();
  showForm   = signal(false);
  editingId  = signal<string | null>(null);

  form = this.emptyForm();

  emptyForm() {
    return { name: '', sku: '', brand: '', price: 0, originalPrice: 0, stock: 0, categoryId: 'clp', shortDescription: '', description: '', thumbnail: '', isFeatured: false, isNew: false, isOnSale: false };
  }

  editProduct(p: Product): void {
    this.editingId.set(p.id);
    this.form = { name: p.name, sku: p.sku, brand: p.brand, price: p.price, originalPrice: p.originalPrice ?? 0, stock: p.stock, categoryId: p.category.id, shortDescription: p.shortDescription, description: p.description, thumbnail: p.thumbnail, isFeatured: p.isFeatured, isNew: p.isNew, isOnSale: p.isOnSale };
    this.showForm.set(true);
  }

  saveProduct(): void {
    if (!this.form.name || !this.form.sku || !this.form.price) {
      this.toast.error('Preencha os campos obrigatórios'); return;
    }
    this.toast.success(this.editingId() ? 'Produto atualizado! (demo)' : 'Produto cadastrado! (demo)');
    this.cancelForm();
  }

  cancelForm(): void { this.showForm.set(false); this.editingId.set(null); this.form = this.emptyForm(); }
  fmt(v: number) { return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
}
