import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
<div class="contact-page">
  <!-- HERO -->
  <div class="contact-hero">
    <div class="container">
      <h1>📞 Entre em Contato</h1>
      <p>Nossa equipe técnica está pronta para ajudar você a encontrar a solução ideal.</p>
    </div>
  </div>

  <div class="container">
    <div class="contact-layout">
      <!-- INFO -->
      <div class="contact-info">
        <h2>Fale Conosco</h2>
        <p class="text-muted">Atendemos empresas de todos os portes com suporte técnico especializado em automação industrial.</p>

        <div class="contact-cards">
          <div class="contact-card">
            <span>📞</span>
            <div>
              <strong>Telefone</strong>
              <a href="tel:+551134567890">(11) 3456-7890</a>
              <span class="text-muted text-sm">Seg-Sex 8h-18h</span>
            </div>
          </div>
          <div class="contact-card">
            <span>📱</span>
            <div>
              <strong>WhatsApp</strong>
              <a href="https://wa.me/5511987654321">(11) 98765-4321</a>
              <span class="text-muted text-sm">Seg-Sex 8h-20h</span>
            </div>
          </div>
          <div class="contact-card">
            <span>✉️</span>
            <div>
              <strong>E-mail</strong>
              <a href="mailto:vendas@indutech.com.br">vendas&#64;indutech.com.br</a>
              <span class="text-muted text-sm">Resposta em até 4h</span>
            </div>
          </div>
          <div class="contact-card">
            <span>📍</span>
            <div>
              <strong>Endereço</strong>
              <span>Av. Industrial, 1200</span>
              <span class="text-muted text-sm">São Paulo – SP, 01310-100</span>
            </div>
          </div>
        </div>

        <div class="working-hours">
          <h3>Horário de Atendimento</h3>
          <table>
            <tr><td>Segunda – Sexta</td><td>08:00 – 18:00</td></tr>
            <tr><td>Sábado</td><td>08:00 – 12:00</td></tr>
            <tr><td>Domingo e Feriados</td><td>Fechado</td></tr>
          </table>
        </div>
      </div>

      <!-- FORM -->
      <div class="contact-form-card">
        <h2>Enviar Mensagem</h2>
        <div *ngIf="!sent()">
          <form (submit)="onSubmit(); $event.preventDefault()">
            <div class="form-group">
              <label class="form-label">Nome completo *</label>
              <input class="form-control" type="text" [(ngModel)]="form.name" name="name" placeholder="Seu nome" required/>
            </div>
            <div class="form-row-2">
              <div class="form-group">
                <label class="form-label">E-mail *</label>
                <input class="form-control" type="email" [(ngModel)]="form.email" name="email" placeholder="seu@email.com" required/>
              </div>
              <div class="form-group">
                <label class="form-label">Telefone</label>
                <input class="form-control" type="tel" [(ngModel)]="form.phone" name="phone" placeholder="(11) 99999-9999"/>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Empresa</label>
              <input class="form-control" type="text" [(ngModel)]="form.company" name="company" placeholder="Nome da empresa"/>
            </div>
            <div class="form-group">
              <label class="form-label">Assunto *</label>
              <select class="form-control" [(ngModel)]="form.subject" name="subject" required>
                <option value="">Selecione o assunto</option>
                <option value="orcamento">Solicitar Orçamento</option>
                <option value="suporte">Suporte Técnico</option>
                <option value="pedido">Dúvida sobre Pedido</option>
                <option value="parceria">Parceria Comercial</option>
                <option value="outro">Outro</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Mensagem *</label>
              <textarea class="form-control" [(ngModel)]="form.message" name="message" rows="5" placeholder="Descreva sua necessidade em detalhes..." required></textarea>
            </div>
            <button class="btn btn-primary btn-full btn-lg" type="submit" [disabled]="loading()">
              {{ loading() ? '⏳ Enviando...' : '📨 Enviar Mensagem' }}
            </button>
          </form>
        </div>
        <div class="success-message" *ngIf="sent()">
          <div class="success-icon">✅</div>
          <h3>Mensagem enviada!</h3>
          <p>Recebemos sua mensagem e retornaremos em até 4 horas úteis.</p>
          <button class="btn btn-primary mt-lg" (click)="sent.set(false)">Enviar outra mensagem</button>
        </div>
      </div>
    </div>
  </div>
</div>
  `,
  styles: [`
    .contact-page { padding-bottom: var(--space-3xl); }
    .contact-hero { background: linear-gradient(135deg, var(--primary-dark), var(--primary)); color: #fff; padding: var(--space-2xl) 0; margin-bottom: var(--space-2xl); h1 { color: #fff; margin-bottom: 10px; } p { color: rgba(255,255,255,.8); font-size: 1.1rem; } }
    .contact-layout { display: grid; grid-template-columns: 1fr 1.2fr; gap: var(--space-2xl); align-items: start; @media (max-width: 900px) { grid-template-columns: 1fr; } }
    .contact-info h2 { margin-bottom: 10px; }
    .contact-cards { display: flex; flex-direction: column; gap: 12px; margin: var(--space-lg) 0; }
    .contact-card { display: flex; align-items: flex-start; gap: 14px; padding: 14px 16px; background: var(--surface); border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); font-size: 1.5rem; > div { display: flex; flex-direction: column; gap: 2px; font-size: 1rem; } strong { font-size: .875rem; font-weight: 700; } a { color: var(--primary); font-weight: 600; } }
    .working-hours { background: var(--gray-50); border-radius: var(--radius-lg); padding: var(--space-lg); h3 { font-size: 1rem; margin-bottom: 12px; } table { width: 100%; } td { padding: 6px 0; font-size: .875rem; color: var(--text-secondary); } td:last-child { text-align: right; font-weight: 600; color: var(--primary); } }
    .contact-form-card { background: var(--surface); border-radius: var(--radius-xl); padding: var(--space-2xl); box-shadow: var(--shadow-md); h2 { margin-bottom: var(--space-lg); } }
    .form-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-md); @media (max-width: 480px) { grid-template-columns: 1fr; } }
    .form-group { margin-bottom: var(--space-md); }
    textarea.form-control { resize: vertical; }
    .success-message { text-align: center; padding: var(--space-2xl) 0; }
    .success-icon { font-size: 4rem; margin-bottom: var(--space-md); }
  `]
})
export class ContactComponent {
  form = { name: '', email: '', phone: '', company: '', subject: '', message: '' };
  loading = signal(false);
  sent    = signal(false);

  async onSubmit(): Promise<void> {
    this.loading.set(true);
    await new Promise(r => setTimeout(r, 1200));
    this.loading.set(false);
    this.sent.set(true);
    this.form = { name: '', email: '', phone: '', company: '', subject: '', message: '' };
  }
}
