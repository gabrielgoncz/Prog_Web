import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink, CommonModule],
  template: `
<footer class="footer">
  <div class="footer__main">
    <div class="container">
      <div class="footer__grid">

        <!-- Brand -->
        <div class="footer__brand">
          <div class="footer__logo">
            <svg width="28" height="28" viewBox="0 0 32 32" fill="none">
              <rect width="32" height="32" rx="6" fill="#1a6ab0"/>
              <path d="M8 10h16M8 16h10M8 22h13" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
              <circle cx="26" cy="22" r="3" fill="#f5a623"/>
            </svg>
            <span>InduTech Store</span>
          </div>
          <p>Sua loja especializada em automação industrial, CLPs, inversores, sensores e ferramentas profissionais para indústria.</p>
          <div class="footer__social">
            <a href="#" aria-label="LinkedIn" class="social-btn">in</a>
            <a href="#" aria-label="Instagram" class="social-btn">ig</a>
            <a href="#" aria-label="YouTube" class="social-btn">yt</a>
            <a href="#" aria-label="WhatsApp" class="social-btn">wp</a>
          </div>
          <div class="footer__certifications">
            <span class="cert-badge">🔒 Site Seguro SSL</span>
            <span class="cert-badge">✅ CNPJ 12.345.678/0001-90</span>
          </div>
        </div>

        <!-- Links -->
        <div class="footer__col">
          <h4 class="footer__col-title">Categorias</h4>
          <ul class="footer__links">
            <li><a routerLink="/catalogo/clps-controladores">CLPs e Controladores</a></li>
            <li><a routerLink="/catalogo/inversores-frequencia">Inversores de Frequência</a></li>
            <li><a routerLink="/catalogo/sensores-detectores">Sensores e Detectores</a></li>
            <li><a routerLink="/catalogo/paineis-componentes">Painéis e Componentes</a></li>
            <li><a routerLink="/catalogo/ferramentas-manuais">Ferramentas Manuais</a></li>
            <li><a routerLink="/catalogo/instrumentacao-medicao">Instrumentação</a></li>
          </ul>
        </div>

        <div class="footer__col">
          <h4 class="footer__col-title">Institucional</h4>
          <ul class="footer__links">
            <li><a routerLink="/sobre">Sobre a Empresa</a></li>
            <li><a routerLink="/contato">Contato</a></li>
            <li><a href="#">Blog Técnico</a></li>
            <li><a href="#">Catálogo PDF</a></li>
            <li><a href="#">Trabalhe Conosco</a></li>
            <li><a href="#">Seja um Revendedor</a></li>
          </ul>
        </div>

        <div class="footer__col">
          <h4 class="footer__col-title">Atendimento</h4>
          <ul class="footer__links">
            <li><a href="#">Central de Ajuda</a></li>
            <li><a href="#">Política de Devolução</a></li>
            <li><a href="#">Prazo de Entrega</a></li>
            <li><a href="#">Formas de Pagamento</a></li>
            <li><a href="#">Minha Conta</a></li>
            <li><a href="#">Rastrear Pedido</a></li>
          </ul>
        </div>

        <!-- Contact -->
        <div class="footer__col">
          <h4 class="footer__col-title">Contato</h4>
          <ul class="footer__contact">
            <li>📍 Av. Industrial, 1200<br>São Paulo - SP, 01310-100</li>
            <li>📞 (11) 3456-7890</li>
            <li>📱 (11) 98765-4321</li>
            <li>✉ vendas&#64;indutech.com.br</li>
            <li>⏰ Seg-Sex: 8h às 18h<br>Sáb: 8h às 12h</li>
          </ul>
          <div class="footer__newsletter">
            <p>Receba ofertas exclusivas:</p>
            <div class="newsletter-form">
              <input type="email" placeholder="seu&#64;email.com" class="newsletter-input"/>
              <button class="newsletter-btn">→</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- PAYMENT METHODS -->
  <div class="footer__payments">
    <div class="container">
      <div class="footer__payments-inner">
        <span class="footer__payments-label">Formas de pagamento:</span>
        <div class="payment-badges">
          <span class="payment-badge">💳 Visa</span>
          <span class="payment-badge">💳 Mastercard</span>
          <span class="payment-badge">💳 Elo</span>
          <span class="payment-badge">💳 Amex</span>
          <span class="payment-badge">📱 PIX</span>
          <span class="payment-badge">📄 Boleto</span>
        </div>
        <span class="footer__payments-label">até 12x sem juros</span>
      </div>
    </div>
  </div>

  <!-- BOTTOM -->
  <div class="footer__bottom">
    <div class="container">
      <div class="footer__bottom-inner">
        <p>© {{ currentYear }} InduTech Store. Todos os direitos reservados.</p>
        <div class="footer__legal">
          <a href="#">Termos de Uso</a>
          <a href="#">Privacidade</a>
          <a href="#">Cookies</a>
        </div>
      </div>
    </div>
  </div>
</footer>
  `,
  styles: [`
    .footer {
      background: var(--gray-900);
      color: var(--gray-300);
      margin-top: auto;
    }
    .footer__main { padding: 60px 0 40px; }
    .footer__grid {
      display: grid;
      grid-template-columns: 1.6fr 1fr 1fr 1fr 1.4fr;
      gap: 40px;
    }
    .footer__logo {
      display: flex; align-items: center; gap: 10px;
      font-family: var(--font-display); font-size: 1.2rem; font-weight: 800;
      color: #fff; margin-bottom: 12px;
    }
    .footer__brand p { font-size: .875rem; line-height: 1.7; color: var(--gray-400); margin-bottom: 16px; }
    .footer__social { display: flex; gap: 8px; margin-bottom: 16px; }
    .social-btn {
      width: 36px; height: 36px; border-radius: 50%;
      background: rgba(255,255,255,.08); color: var(--gray-300);
      display: flex; align-items: center; justify-content: center;
      font-size: .75rem; font-weight: 700; text-transform: uppercase;
      cursor: pointer; transition: all var(--transition-fast);
    }
    .social-btn:hover { background: var(--primary); color: #fff; }
    .footer__certifications { display: flex; flex-direction: column; gap: 6px; }
    .cert-badge { font-size: .75rem; color: var(--gray-400); }

    .footer__col-title {
      font-family: var(--font-display); font-size: .9rem; font-weight: 800;
      text-transform: uppercase; letter-spacing: .08em;
      color: #fff; margin-bottom: 16px;
    }
    .footer__links { display: flex; flex-direction: column; gap: 8px; }
    .footer__links a {
      font-size: .85rem; color: var(--gray-400); text-decoration: none;
      transition: color var(--transition-fast);
    }
    .footer__links a:hover { color: var(--accent); padding-left: 4px; }

    .footer__contact { display: flex; flex-direction: column; gap: 8px; font-size: .85rem; color: var(--gray-400); }
    .footer__newsletter { margin-top: 20px; }
    .footer__newsletter p { font-size: .8rem; color: var(--gray-500); margin-bottom: 8px; }
    .newsletter-form { display: flex; gap: 0; }
    .newsletter-input {
      flex: 1; padding: 8px 12px; background: rgba(255,255,255,.08);
      border: 1px solid rgba(255,255,255,.12); border-radius: var(--radius-md) 0 0 var(--radius-md);
      color: #fff; font-size: .85rem;
    }
    .newsletter-input::placeholder { color: var(--gray-500); }
    .newsletter-btn {
      padding: 8px 14px; background: var(--accent); color: var(--gray-900);
      border-radius: 0 var(--radius-md) var(--radius-md) 0; font-weight: 700; cursor: pointer;
    }

    .footer__payments { background: rgba(255,255,255,.04); border-top: 1px solid rgba(255,255,255,.06); padding: 14px 0; }
    .footer__payments-inner { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
    .footer__payments-label { font-size: .8rem; color: var(--gray-500); }
    .payment-badges { display: flex; gap: 8px; flex-wrap: wrap; }
    .payment-badge {
      padding: 4px 10px; background: rgba(255,255,255,.07);
      border-radius: var(--radius-sm); font-size: .78rem; color: var(--gray-300);
    }

    .footer__bottom { border-top: 1px solid rgba(255,255,255,.06); padding: 16px 0; }
    .footer__bottom-inner { display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap; }
    .footer__bottom p { font-size: .8rem; color: var(--gray-600); }
    .footer__legal { display: flex; gap: 16px; }
    .footer__legal a { font-size: .8rem; color: var(--gray-600); text-decoration: none; }
    .footer__legal a:hover { color: var(--gray-300); }

    @media (max-width: 1100px) {
      .footer__grid { grid-template-columns: 1fr 1fr 1fr; }
      .footer__brand { grid-column: 1 / -1; }
    }
    @media (max-width: 640px) {
      .footer__grid { grid-template-columns: 1fr 1fr; }
      .footer__col:last-child { grid-column: 1 / -1; }
    }
    @media (max-width: 480px) {
      .footer__grid { grid-template-columns: 1fr; }
      .footer__bottom-inner { flex-direction: column; text-align: center; }
    }
  `]
})
export class FooterComponent {
  currentYear = new Date().getFullYear();
}
