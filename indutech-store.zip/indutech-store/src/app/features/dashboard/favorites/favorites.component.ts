import { Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { MockDataService } from '../../../core/services/mock-data.service';
import { ProductCardComponent } from '../../../shared/components/product-card/product-card.component';

@Component({
  selector: 'app-favorites',
  standalone: true,
  imports: [CommonModule, RouterLink, ProductCardComponent],
  template: `
<div class="dashboard-page">
  <div class="container">
    <div class="dashboard-layout">
      <aside class="dashboard-sidebar">
        <nav class="dashboard-nav">
          <a routerLink="/minha-conta" class="dashboard-nav__item">👤 Meu Perfil</a>
          <a routerLink="/minha-conta/pedidos" class="dashboard-nav__item">📦 Meus Pedidos</a>
          <a routerLink="/minha-conta/favoritos" class="dashboard-nav__item active">❤️ Favoritos</a>
        </nav>
      </aside>
      <main>
        <h2>❤️ Meus Favoritos ({{ favorites().length }})</h2>
        <div class="grid-products mt-lg stagger" *ngIf="favorites().length; else noFavs">
          <app-product-card *ngFor="let p of favorites()" [product]="p" class="animate-fade-in"></app-product-card>
        </div>
        <ng-template #noFavs>
          <div class="empty-state">
            <div class="empty-icon">❤️</div>
            <h3>Nenhum favorito ainda</h3>
            <p>Explore nosso catálogo e salve seus produtos favoritos!</p>
            <a routerLink="/catalogo" class="btn btn-primary">Ver Produtos</a>
          </div>
        </ng-template>
      </main>
    </div>
  </div>
</div>
  `,
  styles: [`
    .dashboard-page { padding: var(--space-xl) 0; }
    .dashboard-layout { display: grid; grid-template-columns: 220px 1fr; gap: var(--space-xl); @media (max-width: 768px) { grid-template-columns: 1fr; } }
    .dashboard-sidebar { background: var(--surface); border-radius: var(--radius-lg); padding: var(--space-lg); box-shadow: var(--shadow-sm); height: fit-content; }
    .dashboard-nav { display: flex; flex-direction: column; gap: 4px; }
    .dashboard-nav__item { padding: 10px 12px; border-radius: var(--radius-md); font-size: .9rem; font-weight: 600; color: var(--text-secondary); text-decoration: none; transition: all var(--transition-fast); &:hover { background: var(--gray-50); color: var(--primary); } &.active { background: var(--primary); color: #fff; } }
    h2 { margin-bottom: 0; }
  `]
})
export class FavoritesComponent {
  private auth = inject(AuthService);
  private mock = inject(MockDataService);
  favorites = computed(() => {
    const ids = this.auth.user()?.favorites ?? [];
    return this.mock.getProducts().filter(p => ids.includes(p.id));
  });
}
