# 🏭 InduTech Store — E-commerce de Automação Industrial

E-commerce completo em **Angular 17 Standalone** para venda de CLPs, inversores, sensores, painéis elétricos e ferramentas profissionais.

---

## 📁 Estrutura do Projeto

```
indutech-store/
├── src/
│   ├── app/
│   │   ├── core/
│   │   │   ├── guards/
│   │   │   │   └── auth.guard.ts          ← Proteção de rotas (auth + admin)
│   │   │   ├── models/
│   │   │   │   └── index.ts               ← Todas as interfaces TypeScript
│   │   │   └── services/
│   │   │       ├── auth.service.ts         ← Autenticação com localStorage
│   │   │       ├── cart.service.ts         ← Carrinho reativo com Signals
│   │   │       ├── mock-data.service.ts    ← 12 produtos + 6 categorias
│   │   │       ├── order.service.ts        ← Gerenciamento de pedidos
│   │   │       └── toast.service.ts        ← Notificações toast
│   │   ├── shared/
│   │   │   └── components/
│   │   │       ├── header/                 ← Header com busca, carrinho, menu
│   │   │       ├── footer/                 ← Footer completo
│   │   │       ├── product-card/           ← Card de produto reutilizável
│   │   │       └── toast-container/        ← Container de notificações
│   │   ├── features/
│   │   │   ├── home/                       ← Página inicial com slider e destaques
│   │   │   ├── catalog/                    ← Catálogo com filtros e busca
│   │   │   ├── product-detail/             ← Página de detalhes + avaliações
│   │   │   ├── cart/                       ← Carrinho de compras
│   │   │   ├── checkout/                   ← Checkout 3 etapas (endereço→pagamento→confirmação)
│   │   │   ├── auth/
│   │   │   │   ├── login/                  ← Login com demo hints
│   │   │   │   └── register/               ← Cadastro de usuário
│   │   │   ├── dashboard/
│   │   │   │   ├── dashboard.component.ts  ← Painel do cliente
│   │   │   │   ├── orders/                 ← Histórico de pedidos
│   │   │   │   └── favorites/              ← Produtos favoritos
│   │   │   ├── admin/
│   │   │   │   ├── admin.component.ts      ← Painel administrativo
│   │   │   │   └── products/               ← CRUD de produtos (admin)
│   │   │   ├── contact/                    ← Formulário de contato
│   │   │   ├── about/                      ← Sobre a empresa
│   │   │   └── not-found/                  ← Página 404
│   │   ├── app.component.ts
│   │   ├── app.config.ts
│   │   └── app.routes.ts
│   ├── environments/
│   │   ├── environment.ts
│   │   └── environment.prod.ts
│   ├── styles.scss                          ← Design system completo
│   ├── index.html
│   └── main.ts
├── angular.json
├── package.json
└── tsconfig.json
```

---

## 🚀 Como Instalar e Executar

### Pré-requisitos
- **Node.js** v18+ → [nodejs.org](https://nodejs.org)
- **Angular CLI** v17+

### Passo 1 — Instalar o Angular CLI (se não tiver)
```bash
npm install -g @angular/cli@17
```

### Passo 2 — Entrar na pasta do projeto
```bash
cd indutech-store
```

### Passo 3 — Instalar dependências
```bash
npm install
```

### Passo 4 — Executar em desenvolvimento
```bash
ng serve
```
Acesse: **http://localhost:4200**

### Passo 5 — Build para produção
```bash
ng build --configuration production
```
Os arquivos serão gerados em `dist/indutech-store/`

---

## 🔑 Contas de Demonstração

| Tipo      | E-mail                      | Senha     |
|-----------|---------------------------  |-----------|
| **Admin** | admin@indutech.com.br       | admin123  |
| **Cliente** | demo@indutech.com.br      | senha123  |

> As contas são criadas automaticamente no `localStorage` ao iniciar o app.

---

## 🧩 Funcionalidades Implementadas

### Páginas
| Rota | Componente | Descrição |
|------|-----------|-----------|
| `/` | HomeComponent | Banner slider, categorias, destaques, promoções |
| `/catalogo` | CatalogComponent | Grid + filtros sidebar + busca + ordenação + paginação |
| `/catalogo/:category` | CatalogComponent | Filtra por categoria via URL |
| `/produto/:slug` | ProductDetailComponent | Galeria, specs, tabs, avaliações, relacionados |
| `/carrinho` | CartComponent | Lista de itens, quantidades, resumo com frete |
| `/checkout` | CheckoutComponent | 3 etapas: endereço → pagamento → confirmação |
| `/login` | LoginComponent | Login com validação |
| `/cadastro` | RegisterComponent | Cadastro com validação |
| `/minha-conta` | DashboardComponent | Stats + pedidos recentes |
| `/minha-conta/pedidos` | OrdersComponent | Histórico de pedidos |
| `/minha-conta/favoritos` | FavoritesComponent | Produtos favoritados |
| `/admin` | AdminComponent | Painel administrativo |
| `/admin/produtos` | AdminProductsComponent | Listagem + formulário de produto |
| `/contato` | ContactComponent | Formulário + mapa de contatos |
| `/sobre` | AboutComponent | História, missão, marcas |

### Funcionalidades
- ✅ **Busca inteligente** com autocomplete no header
- ✅ **Filtros** por categoria, marca, estoque, promoção
- ✅ **Ordenação** por preço, avaliação, nome, novidade
- ✅ **Carrinho** reativo com Signals (persistent localStorage)
- ✅ **Sistema de favoritos** por usuário
- ✅ **Checkout** com cálculo de frete e simulação de pagamento
- ✅ **PIX, Cartão e Boleto** (integração simulada)
- ✅ **Autenticação** com guards de rota
- ✅ **Painel admin** com listagem e formulário de produto
- ✅ **Histórico de pedidos** persistido em localStorage
- ✅ **Notificações toast** responsivas
- ✅ **Lazy loading** em todas as rotas
- ✅ **Responsivo** mobile-first

---

## 🎨 Design System

### Cores Industriais
```scss
--primary:       #0a4f8c   /* Azul industrial */
--primary-light: #1a6ab0
--primary-dark:  #063363
--accent:        #f5a623   /* Âmbar/laranja */
--gray-900:      #0d1117   /* Quase preto */
--success:       #2ecc71
--danger:        #e53e3e
```

### Tipografia
- **Display:** Barlow Condensed (títulos, preços, CTAs)
- **Body:** Barlow (textos, descrições)

### Componentes Globais (styles.scss)
- Sistema de botões: `.btn`, `.btn-primary`, `.btn-accent`, `.btn-outline`
- Formulários: `.form-control`, `.form-group`, `.form-label`
- Badges, chips, cards, toasts
- Grid de produtos responsivo
- Animações: fadeIn, slideLeft, scaleIn

---

## 🔧 Tecnologias Utilizadas

| Tecnologia | Versão | Uso |
|-----------|--------|-----|
| Angular | 17 | Framework principal |
| TypeScript | 5.2 | Lógica de negócio tipada |
| Angular Signals | 17 | Estado reativo sem RxJS |
| SCSS | — | Estilização modular |
| Angular Router | 17 | Roteamento com lazy loading |
| LocalStorage | — | Persistência de dados |

---

## 📦 Como Adicionar Novos Produtos

Edite o arquivo `src/app/core/services/mock-data.service.ts` e adicione um objeto ao array `products`:

```typescript
{
  id: 'p013',
  name: 'Nome do Produto',
  slug: 'slug-do-produto',        // URL amigável, único
  description: 'Descrição longa...',
  shortDescription: 'Descrição curta',
  price: 999.00,
  originalPrice: 1200.00,         // Preço antes do desconto (opcional)
  discount: 17,                   // % de desconto (opcional)
  images: ['https://url-da-imagem.jpg'],
  thumbnail: 'https://url-thumb.jpg',
  category: { id: 'clp', name: 'CLPs e Controladores', slug: 'clps-controladores', icon: '🖥️' },
  brand: 'Marca',
  sku: 'MARCA-MODELO-REF',
  stock: 10,
  rating: 4.5,
  reviewCount: 20,
  specifications: [
    { key: 'Tensão', value: '24VDC' },
    { key: 'Potência', value: '100W' },
  ],
  tags: ['tag1', 'tag2'],
  isFeatured: false,
  isNew: true,
  isOnSale: false,
  weight: 0.5,
  createdAt: new Date(),
}
```

---

## 🌐 Deploy

### Netlify (Recomendado — Gratuito)
```bash
# 1. Build
ng build --configuration production

# 2. Arraste a pasta dist/indutech-store/ para app.netlify.com/drop

# 3. Configure redirects (crie _redirects na pasta public/):
/*  /index.html  200
```

### Vercel
```bash
npm install -g vercel
ng build --configuration production
vercel dist/indutech-store/
```

### GitHub Pages
```bash
ng add angular-cli-ghpages
ng deploy --base-href=/indutech-store/
```

---

## 🔌 Integração com API Real (Próximos Passos)

Para conectar com um backend real, substitua o `MockDataService` por chamadas HTTP:

```typescript
// Substitua mock-data.service.ts por:
import { HttpClient } from '@angular/common/http';
import { environment } from '@environments/environment';

@Injectable({ providedIn: 'root' })
export class ProductService {
  private http = inject(HttpClient);
  private base = environment.apiUrl;

  getProducts() {
    return this.http.get<Product[]>(`${this.base}/products`);
  }
  getProductBySlug(slug: string) {
    return this.http.get<Product>(`${this.base}/products/${slug}`);
  }
}
```

Adicione ao `app.config.ts`:
```typescript
import { provideHttpClient } from '@angular/common/http';
// ...
providers: [provideHttpClient(), ...]
```

---

## 🛠 Scripts Disponíveis

```bash
ng serve               # Desenvolvimento (localhost:4200)
ng build               # Build de desenvolvimento
ng build --configuration production  # Build produção otimizado
ng test                # Testes unitários
ng lint                # Linting TypeScript
```

---

## 📋 Checklist de Personalização

- [ ] Trocar logo e nome da empresa no `header.component.html` e `footer.component.ts`
- [ ] Atualizar dados de contato (telefone, e-mail, endereço)
- [ ] Adicionar produtos reais no `mock-data.service.ts`
- [ ] Integrar gateway de pagamento real (Stripe, PagSeguro, Mercado Pago)
- [ ] Conectar API de CEP (ViaCEP) para autocompletar endereço
- [ ] Integrar API dos Correios para cálculo de frete real
- [ ] Configurar e-mails transacionais (SendGrid, Resend)
- [ ] Adicionar Google Analytics
- [ ] Configurar domínio personalizado

---

## 🤝 Suporte

Desenvolvido para a **InduTech Store** — Sistema completo de e-commerce industrial em Angular 17.

Para dúvidas sobre personalização ou integração com backend, consulte a [documentação oficial do Angular](https://angular.dev).
