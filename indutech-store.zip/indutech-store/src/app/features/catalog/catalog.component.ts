// =====================================================
// CATALOG COMPONENT
// Catálogo com filtros, busca e ordenação
// =====================================================
import { Component, OnInit, inject, signal, computed, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MockDataService } from '../../core/services/mock-data.service';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { Product, ProductFilters, SortOption } from '../../core/models';

@Component({
  selector: 'app-catalog',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ProductCardComponent],
  templateUrl: './catalog.component.html',
  styleUrl: './catalog.component.scss',
})
export class CatalogComponent implements OnInit {
  private mock   = inject(MockDataService);
  private route  = inject(ActivatedRoute);
  private router = inject(Router);

  allProducts  = this.mock.getProducts();
  categories   = this.mock.getCategories();

  filters = signal<ProductFilters>({
    search: '',
    categoryId: undefined,
    brands: [],
    minPrice: 0,
    maxPrice: 99999,
    inStock: false,
    onSale: false,
    sortBy: 'relevance',
  });

  sidebarOpen  = signal(false);
  page         = signal(1);
  readonly pageSize = 12;

  brands = [...new Set(this.allProducts.map(p => p.brand))].sort();

  filteredProducts = computed(() => {
    const f = this.filters();
    let products = [...this.allProducts];

    if (f.search) {
      const q = f.search.toLowerCase();
      products = products.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      );
    }
    if (f.categoryId) {
      products = products.filter(p => p.category.id === f.categoryId);
    }
    if (f.brands && f.brands.length > 0) {
      products = products.filter(p => f.brands!.includes(p.brand));
    }
    if (f.minPrice !== undefined) {
      products = products.filter(p => p.price >= f.minPrice!);
    }
    if (f.maxPrice !== undefined && f.maxPrice < 99999) {
      products = products.filter(p => p.price <= f.maxPrice!);
    }
    if (f.inStock) {
      products = products.filter(p => p.stock > 0);
    }
    if (f.onSale) {
      products = products.filter(p => p.isOnSale);
    }

    // Sorting
    switch (f.sortBy) {
      case 'price_asc':  products.sort((a, b) => a.price - b.price); break;
      case 'price_desc': products.sort((a, b) => b.price - a.price); break;
      case 'name_asc':   products.sort((a, b) => a.name.localeCompare(b.name)); break;
      case 'rating':     products.sort((a, b) => b.rating - a.rating); break;
      case 'newest':     products.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); break;
    }

    return products;
  });

  paginatedProducts = computed(() => {
    const start = (this.page() - 1) * this.pageSize;
    return this.filteredProducts().slice(start, start + this.pageSize);
  });

  totalPages = computed(() => Math.ceil(this.filteredProducts().length / this.pageSize));

  currentCategoryName = computed(() => {
    const f = this.filters();
    if (!f.categoryId) return 'Todos os Produtos';
    return this.categories.find(c => c.id === f.categoryId)?.name ?? 'Produtos';
  });

  ngOnInit(): void {
    // Read category from route param
    this.route.params.subscribe(params => {
      const slug = params['category'];
      if (slug) {
        const cat = this.categories.find(c => c.slug === slug);
        if (cat) this.setCategory(cat.id);
      }
    });
    // Read search query
    this.route.queryParams.subscribe(qp => {
      if (qp['q']) this.setSearch(qp['q']);
    });
  }

  setCategory(id: string | undefined): void {
    this.filters.update(f => ({ ...f, categoryId: id }));
    this.page.set(1);
  }

  setSearch(q: string): void {
    this.filters.update(f => ({ ...f, search: q }));
    this.page.set(1);
  }

  toggleBrand(brand: string): void {
    this.filters.update(f => {
      const brands = f.brands ?? [];
      const next = brands.includes(brand) ? brands.filter(b => b !== brand) : [...brands, brand];
      return { ...f, brands: next };
    });
    this.page.set(1);
  }

  setSort(sort: SortOption): void {
    this.filters.update(f => ({ ...f, sortBy: sort }));
  }

  toggleInStock(): void {
    this.filters.update(f => ({ ...f, inStock: !f.inStock }));
    this.page.set(1);
  }

  toggleOnSale(): void {
    this.filters.update(f => ({ ...f, onSale: !f.onSale }));
    this.page.set(1);
  }

  clearFilters(): void {
    this.filters.set({ search: '', categoryId: undefined, brands: [], minPrice: 0, maxPrice: 99999, inStock: false, onSale: false, sortBy: 'relevance' });
    this.page.set(1);
  }

  setPage(p: number): void {
    this.page.set(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  getPages(): number[] {
    return Array.from({ length: this.totalPages() }, (_, i) => i + 1);
  }

  hasBrand(b: string): boolean { return (this.filters().brands ?? []).includes(b); }
}
