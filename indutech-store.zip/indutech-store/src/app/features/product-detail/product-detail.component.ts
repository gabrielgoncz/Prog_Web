import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MockDataService } from '../../core/services/mock-data.service';
import { CartService } from '../../core/services/cart.service';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { Product } from '../../core/models';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule, ProductCardComponent],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.scss',
})
export class ProductDetailComponent implements OnInit {
  private mock   = inject(MockDataService);
  private cart   = inject(CartService);
  private auth   = inject(AuthService);
  private toast  = inject(ToastService);
  private route  = inject(ActivatedRoute);
  private router = inject(Router);

  product    = signal<Product | null>(null);
  quantity   = signal(1);
  activeImg  = signal(0);
  activeTab  = signal<'desc' | 'specs' | 'reviews'>('desc');

  related    = signal<Product[]>([]);
  isFav      = computed(() => this.product() ? this.auth.isFavorite(this.product()!.id) : false);
  inCart     = computed(() => this.product() ? this.cart.isInCart(this.product()!.id) : false);

  stars = [1, 2, 3, 4, 5];

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      const p = this.mock.getProductBySlug(params['slug']);
      if (!p) { this.router.navigate(['/catalogo']); return; }
      this.product.set(p);
      this.activeImg.set(0);
      this.quantity.set(1);
      this.related.set(
        this.mock.getProductsByCategory(p.category.id).filter(r => r.id !== p.id).slice(0, 4)
      );
    });
  }

  addToCart(): void {
    const p = this.product();
    if (!p) return;
    this.cart.addItem(p, this.quantity());
    this.toast.success(`${this.quantity()} × "${p.name.substring(0, 35)}..." no carrinho!`);
  }

  buyNow(): void {
    this.addToCart();
    this.router.navigate(['/carrinho']);
  }

  toggleFav(): void {
    if (!this.auth.isLoggedIn()) { this.toast.info('Faça login para favoritar'); return; }
    this.auth.toggleFavorite(this.product()!.id);
    this.toast.success(this.isFav() ? 'Adicionado aos favoritos!' : 'Removido dos favoritos');
  }

  incQty(): void {
    const p = this.product();
    if (p && this.quantity() < p.stock) this.quantity.update(q => q + 1);
  }
  decQty(): void { if (this.quantity() > 1) this.quantity.update(q => q - 1); }

  fmt(p: number) { return p.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
  fmtInstallments(p: number) { return this.fmt(p / 12); }
}
