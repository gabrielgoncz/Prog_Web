import { Component, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CartService } from '../../core/services/cart.service';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.scss',
})
export class CartComponent {
  cart  = inject(CartService);
  toast = inject(ToastService);

  items    = this.cart.items;
  subtotal = this.cart.subtotal;
  shipping = this.cart.shipping;
  total    = this.cart.total;

  remove(id: string, name: string): void {
    this.cart.removeItem(id);
    this.toast.info(`"${name.substring(0,35)}..." removido do carrinho`);
  }

  updateQty(id: string, qty: number): void { this.cart.updateQuantity(id, qty); }
  clearCart(): void { this.cart.clear(); this.toast.info('Carrinho esvaziado'); }

  fmt(v: number) { return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
}
