import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
<div class="not-found">
  <div class="not-found__content">
    <div class="not-found__code">404</div>
    <h1>Página não encontrada</h1>
    <p>A página que você procura não existe ou foi movida.</p>
    <div class="not-found__actions">
      <a routerLink="/" class="btn btn-primary btn-lg">🏠 Voltar ao Início</a>
      <a routerLink="/catalogo" class="btn btn-outline btn-lg">📦 Ver Catálogo</a>
    </div>
  </div>
</div>
  `,
  styles: [`
    .not-found { min-height: 70vh; display: flex; align-items: center; justify-content: center; padding: var(--space-xl); }
    .not-found__content { text-align: center; }
    .not-found__code { font-family: var(--font-display); font-size: 8rem; font-weight: 900; color: var(--gray-200); line-height: 1; margin-bottom: -20px; }
    h1 { margin-bottom: 12px; }
    p { color: var(--text-muted); margin-bottom: var(--space-xl); }
    .not-found__actions { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
  `]
})
export class NotFoundComponent {}
