import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router, ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <svg width="40" height="40" viewBox="0 0 32 32" fill="none">
        <rect width="32" height="32" rx="6" fill="#0a4f8c"/>
        <path d="M8 10h16M8 16h10M8 22h13" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
        <circle cx="26" cy="22" r="3" fill="#f5a623"/>
      </svg>
      <span>InduTech Store</span>
    </div>

    <h1>Bem-vindo de volta</h1>
    <p class="auth-subtitle">Acesse sua conta para continuar</p>

    <form class="auth-form" (submit)="onSubmit(); $event.preventDefault()">
      <div class="form-group">
        <label class="form-label">E-mail</label>
        <input class="form-control" type="email" [(ngModel)]="email" name="email"
          placeholder="seu@email.com" required autocomplete="email"/>
      </div>
      <div class="form-group">
        <label class="form-label">Senha</label>
        <div class="password-wrap">
          <input class="form-control" [type]="showPwd() ? 'text' : 'password'"
            [(ngModel)]="password" name="password" placeholder="••••••••" required/>
          <button type="button" class="pwd-toggle" (click)="showPwd.update(v => !v)">
            {{ showPwd() ? '🙈' : '👁' }}
          </button>
        </div>
      </div>

      <div class="auth-demo-hint">
        <strong>Contas demo:</strong><br>
        Admin: admin&#64;indutech.com.br / admin123<br>
        Cliente: demo&#64;indutech.com.br / senha123
      </div>

      <div class="form-error" *ngIf="error()">{{ error() }}</div>

      <button class="btn btn-primary btn-full btn-lg" type="submit" [disabled]="loading()">
        {{ loading() ? 'Entrando...' : 'Entrar' }}
      </button>
    </form>

    <div class="divider"><span>ou</span></div>

    <p class="auth-switch">
      Não tem conta? <a routerLink="/cadastro">Criar conta grátis</a>
    </p>
  </div>
</div>
  `,
  styles: [`
    .auth-page {
      min-height: calc(100vh - 180px); display: flex; align-items: center; justify-content: center;
      padding: var(--space-xl) var(--space-md); background: var(--gray-50);
    }
    .auth-card {
      width: 100%; max-width: 440px; background: var(--surface);
      border-radius: var(--radius-xl); padding: var(--space-2xl);
      box-shadow: var(--shadow-xl);
    }
    .auth-logo {
      display: flex; align-items: center; gap: 10px; margin-bottom: var(--space-xl);
      font-family: var(--font-display); font-size: 1.2rem; font-weight: 800; color: var(--primary);
    }
    h1 { font-size: 1.75rem; margin-bottom: 6px; }
    .auth-subtitle { color: var(--text-muted); margin-bottom: var(--space-xl); }
    .auth-form { display: flex; flex-direction: column; gap: 0; }
    .password-wrap { position: relative; }
    .password-wrap .form-control { padding-right: 44px; }
    .pwd-toggle {
      position: absolute; right: 12px; top: 50%; transform: translateY(-50%);
      background: none; cursor: pointer; font-size: 1rem;
    }
    .auth-demo-hint {
      background: rgba(10,79,140,.06); border: 1px solid rgba(10,79,140,.15);
      border-radius: var(--radius-md); padding: 12px; font-size: .78rem;
      color: var(--text-secondary); line-height: 1.6; margin-bottom: var(--space-md);
    }
    .form-error { color: var(--danger); font-size: .875rem; margin-bottom: var(--space-md); }
    .auth-switch { text-align: center; font-size: .9rem; margin-top: var(--space-lg); }
    .auth-switch a { color: var(--primary); font-weight: 700; }
  `]
})
export class LoginComponent {
  private auth   = inject(AuthService);
  private toast  = inject(ToastService);
  private router = inject(Router);
  private route  = inject(ActivatedRoute);

  email    = '';
  password = '';
  loading  = signal(false);
  error    = signal('');
  showPwd  = signal(false);

  async onSubmit(): Promise<void> {
    if (!this.email || !this.password) { this.error.set('Preencha e-mail e senha'); return; }
    this.loading.set(true); this.error.set('');
    try {
      await this.auth.login({ email: this.email, password: this.password });
      this.toast.success('Bem-vindo de volta! 🎉');
      const redirect = this.route.snapshot.queryParams['redirect'] || '/';
      this.router.navigateByUrl(redirect);
    } catch (e: any) {
      this.error.set(e.message || 'Erro ao entrar. Verifique suas credenciais.');
    } finally {
      this.loading.set(false);
    }
  }
}
