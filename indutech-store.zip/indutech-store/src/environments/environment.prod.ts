export const environment = {
  production: true,
  apiUrl: 'https://api.indutech.com.br/api',
  appName: 'InduTech Store',
};
