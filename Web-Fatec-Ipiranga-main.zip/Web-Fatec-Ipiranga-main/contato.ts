import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { ContatoModel } from '../model/contato';

@Component({
  selector: 'app-contato',
  imports: [FormsModule, CommonModule],
  templateUrl: './contato.html',
  styleUrl: './contato.css',
})
export class Contato {
  public alerta: string = "";
  public obj: ContatoModel = new ContatoModel();

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  public enviar() {
    if (isPlatformBrowser(this.platformId)) {
      let json = JSON.stringify(this.obj);
      localStorage.setItem("meuContato", json);
    }
    this.alerta = "Sua mensagem foi enviada com sucesso!";
    this.obj = new ContatoModel();
  }
}