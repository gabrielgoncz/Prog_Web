import { Component, Input, inject, computed, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Product } from '../../../core/models';
import { CartService } from '../../../core/services/cart.service';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-product-card',
  standalone: true,
  imports: [RouterLink, CommonModule],
  template: `
<div class="product-card" [class.product-card--featured]="featured">
  <!-- Badges -->
  <div class="product-card__badges">
    <span class="badge badge-danger" *ngIf="product.isOnSale && product.discount">
      -{{ product.discount }}%
    </span>
    <span class="badge badge-primary" *ngIf="product.isNew">NOVO</span>
    <span class="badge" style="background:var(--gray-500);color:#fff" *ngIf="product.stock === 0">ESGOTADO</span>
  </div>

  <!-- Favorite -->
  <button class="product-card__fav" (click)="toggleFav($event)" [class.active]="isFav()" aria-label="Favoritar">
    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"
        [attr.fill]="isFav() ? 'var(--danger)' : 'none'"
        [attr.stroke]="isFav() ? 'var(--danger)' : 'currentColor'"/>
    </svg>
  </button>

  <!-- Image -->
  <a [routerLink]="['/produto', product.slug]" class="product-card__img-wrap">
    <img [src]="product.thumbnail" [alt]="product.name" class="product-card__img" loading="lazy"/>
  </a>

  <!-- Info -->
  <div class="product-card__body">
    <span class="product-card__brand">{{ product.brand }}</span>
    <a [routerLink]="['/produto', product.slug]" class="product-card__name">{{ product.name }}</a>

    <!-- Rating -->
    <div class="product-card__rating">
      <span class="stars">
        <ng-container *ngFor="let s of [1,2,3,4,5]">
          {{ s <= product.rating ? '★' : '☆' }}
        </ng-container>
      </span>
      <span class="text-muted text-sm">({{ product.reviewCount }})</span>
    </div>

    <!-- Price -->
    <div class="product-card__price">
      <span class="price-original" *ngIf="product.originalPrice">{{ fmt(product.originalPrice) }}</span>
      <span class="price price-md">{{ fmt(product.price) }}</span>
      <span class="price-installments" *ngIf="product.price > 100">
        ou {{ fmt(product.price / 12) }}/mês em 12x
      </span>
    </div>

    <!-- CTA -->
    <button
      class="btn btn-primary btn-full btn-sm product-card__cta"
      (click)="addToCart()"
      [disabled]="product.stock === 0"
    >
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
        <line x1="3" y1="6" x2="21" y2="6"/>
        <path d="M16 10a4 4 0 0 1-8 0"/>
      </svg>
      {{ product.stock === 0 ? 'Esgotado' : 'Adicionar ao Carrinho' }}
    </button>
  </div>
</div>
  `,
  styles: [`
    .product-card {
      background: var(--surface-card);
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-sm);
      overflow: hidden;
      transition: box-shadow var(--transition-base), transform var(--transition-base);
      position: relative;
      display: flex; flex-direction: column;
      &:hover {
        box-shadow: var(--shadow-lg);
        transform: translateY(-3px);
        .product-card__img { transform: scale(1.04); }
      }
    }
    .product-card--featured { border: 2px solid var(--accent); }

    .product-card__badges {
      position: absolute; top: 10px; left: 10px;
      display: flex; flex-direction: column; gap: 4px; z-index: 2;
    }

    .product-card__fav {
      position: absolute; top: 10px; right: 10px; z-index: 2;
      width: 34px; height: 34px; border-radius: 50%;
      background: rgba(255,255,255,.9); color: var(--gray-500);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer; transition: all var(--transition-fast);
      box-shadow: var(--shadow-sm);
      &:hover, &.active { background: #fff; color: var(--danger); transform: scale(1.1); }
    }

    .product-card__img-wrap {
      display: block; overflow: hidden;
      background: var(--gray-50); aspect-ratio: 4/3;
    }
    .product-card__img {
      width: 100%; height: 100%; object-fit: cover;
      transition: transform var(--transition-slow);
    }

    .product-card__body {
      padding: 16px; display: flex; flex-direction: column; gap: 6px; flex: 1;
    }
    .product-card__brand {
      font-size: .72rem; font-weight: 700; text-transform: uppercase;
      letter-spacing: .08em; color: var(--primary);
    }
    .product-card__name {
      font-size: .9rem; font-weight: 600; color: var(--text-primary);
      line-height: 1.35; text-decoration: none;
      display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
      &:hover { color: var(--primary); }
    }
    .product-card__rating { display: flex; align-items: center; gap: 6px; }

    .product-card__price { display: flex; flex-direction: column; gap: 2px; margin-top: 4px; }
    .price-installments { font-size: .72rem; color: var(--text-muted); }

    .product-card__cta { margin-top: auto; }
  `]
})
export class ProductCardComponent {
  @Input({ required: true }) product!: Product;
  @Input() featured = false;

  private cart  = inject(CartService);
  private auth  = inject(AuthService);
  private toast = inject(ToastService);

  isFav = computed(() => this.auth.isFavorite(this.product.id));

  fmt(p: number) { return p.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }

  addToCart(): void {
    this.cart.addItem(this.product);
    this.toast.success(`"${this.product.name.substring(0, 40)}..." adicionado ao carrinho!`);
  }

  toggleFav(e: Event): void {
    e.preventDefault(); e.stopPropagation();
    if (!this.auth.isLoggedIn()) { this.toast.info('Faça login para favoritar produtos'); return; }
    this.auth.toggleFavorite(this.product.id);
    this.toast.success(this.isFav() ? 'Adicionado aos favoritos!' : 'Removido dos favoritos');
  }
}
