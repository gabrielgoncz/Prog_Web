import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { OrderService } from '../../../core/services/order.service';

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
<div class="dashboard-page">
  <div class="container">
    <div class="dashboard-layout">
      <aside class="dashboard-sidebar">
        <nav class="dashboard-nav">
          <a routerLink="/minha-conta" class="dashboard-nav__item">👤 Meu Perfil</a>
          <a routerLink="/minha-conta/pedidos" class="dashboard-nav__item active">📦 Meus Pedidos</a>
          <a routerLink="/minha-conta/favoritos" class="dashboard-nav__item">❤️ Favoritos</a>
        </nav>
      </aside>
      <main>
        <h2>📦 Meus Pedidos</h2>
        <div *ngIf="orders().length; else noOrders">
          <div class="order-detail-card" *ngFor="let order of orders()">
            <div class="order-detail-card__header">
              <div>
                <strong>{{ order.id }}</strong>
                <span class="text-muted text-sm ml-md">{{ order.createdAt | date:'dd/MM/yyyy' }}</span>
              </div>
              <span class="order-status status-{{ order.status }}">{{ statusLabel(order.status) }}</span>
            </div>
            <div class="order-detail-card__items">
              <div class="order-item" *ngFor="let item of order.items">
                <img [src]="item.product.thumbnail" [alt]="item.product.name" class="order-item__img"/>
                <div class="order-item__info">
                  <span class="fw-600">{{ item.product.name }}</span>
                  <span class="text-muted text-sm">{{ item.quantity }} × {{ fmt(item.product.price) }}</span>
                </div>
                <span class="price price-sm">{{ fmt(item.product.price * item.quantity) }}</span>
              </div>
            </div>
            <div class="order-detail-card__footer">
              <div>
                <span class="text-muted text-sm">Endereço: {{ order.address.street }}, {{ order.address.number }} – {{ order.address.city }}/{{ order.address.state }}</span>
              </div>
              <div class="text-right">
                <span class="text-muted text-sm">Frete: {{ order.shipping === 0 ? 'Grátis' : fmt(order.shipping) }}</span><br>
                <strong class="price price-md">Total: {{ fmt(order.total) }}</strong>
              </div>
            </div>
          </div>
        </div>
        <ng-template #noOrders>
          <div class="empty-state">
            <div class="empty-icon">📦</div>
            <h3>Nenhum pedido ainda</h3>
            <a routerLink="/catalogo" class="btn btn-primary">Ir às Compras</a>
          </div>
        </ng-template>
      </main>
    </div>
  </div>
</div>
  `,
  styles: [`
    .dashboard-page { padding: var(--space-xl) 0; }
    .dashboard-layout { display: grid; grid-template-columns: 220px 1fr; gap: var(--space-xl); @media (max-width: 768px) { grid-template-columns: 1fr; } }
    .dashboard-sidebar { background: var(--surface); border-radius: var(--radius-lg); padding: var(--space-lg); box-shadow: var(--shadow-sm); height: fit-content; }
    .dashboard-nav { display: flex; flex-direction: column; gap: 4px; }
    .dashboard-nav__item { padding: 10px 12px; border-radius: var(--radius-md); font-size: .9rem; font-weight: 600; color: var(--text-secondary); text-decoration: none; transition: all var(--transition-fast); &:hover { background: var(--gray-50); color: var(--primary); } &.active { background: var(--primary); color: #fff; } }
    h2 { margin-bottom: var(--space-lg); }
    .order-detail-card { background: var(--surface); border-radius: var(--radius-lg); box-shadow: var(--shadow-sm); margin-bottom: var(--space-md); overflow: hidden; &__header { display: flex; justify-content: space-between; align-items: center; padding: 14px 18px; border-bottom: 1px solid var(--gray-100); } &__items { padding: 14px 18px; display: flex; flex-direction: column; gap: 12px; } &__footer { padding: 12px 18px; background: var(--gray-50); display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; font-size: .875rem; } }
    .order-item { display: flex; align-items: center; gap: 12px; &__img { width: 52px; height: 52px; object-fit: cover; border-radius: var(--radius-sm); background: var(--gray-100); } &__info { flex: 1; display: flex; flex-direction: column; } }
    .order-status { padding: 3px 10px; border-radius: var(--radius-full); font-size: .72rem; font-weight: 700; text-transform: uppercase; }
    .status-confirmed { background: rgba(10,79,140,.1); color: var(--primary); }
    .status-shipped   { background: rgba(46,204,113,.1); color: #1a9e55; }
    .status-delivered { background: rgba(46,204,113,.15); color: #1a9e55; }
    .status-cancelled { background: rgba(229,62,62,.1); color: var(--danger); }
    .status-pending   { background: var(--gray-100); color: var(--text-muted); }
    .ml-md { margin-left: var(--space-md); }
  `]
})
export class OrdersComponent {
  private auth     = inject(AuthService);
  private orderSvc = inject(OrderService);
  orders = () => this.orderSvc.getOrdersByUser(this.auth.user()?.id ?? '');
  fmt(v: number) { return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
  statusLabel(s: string) { const m: any = { pending:'Pendente', confirmed:'Confirmado', processing:'Em Processo', shipped:'Enviado', delivered:'Entregue', cancelled:'Cancelado' }; return m[s] ?? s; }
}
