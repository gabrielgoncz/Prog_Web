import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
<div class="about-page">
  <!-- HERO -->
  <div class="about-hero">
    <div class="container">
      <div class="about-hero__content">
        <span class="about-hero__label">Desde 2009</span>
        <h1>Especialistas em Automação Industrial</h1>
        <p>A InduTech Store nasceu da paixão pela tecnologia industrial e do compromisso em fornecer soluções de alta qualidade para o setor produtivo brasileiro.</p>
      </div>
    </div>
  </div>

  <!-- NUMBERS -->
  <section class="section section-sm" style="background: var(--surface)">
    <div class="container">
      <div class="numbers-grid">
        <div class="number-card" *ngFor="let n of numbers">
          <strong class="number-card__value">{{ n.value }}</strong>
          <span class="number-card__label">{{ n.label }}</span>
        </div>
      </div>
    </div>
  </section>

  <!-- MISSION -->
  <section class="section">
    <div class="container">
      <div class="mission-grid">
        <div class="mission-card" *ngFor="let m of mission">
          <span class="mission-card__icon">{{ m.icon }}</span>
          <h3>{{ m.title }}</h3>
          <p>{{ m.text }}</p>
        </div>
      </div>
    </div>
  </section>

  <!-- STORY -->
  <section class="section" style="background: var(--surface)">
    <div class="container">
      <div class="story-layout">
        <div>
          <h2>Nossa História</h2>
          <p>Fundada em 2009 na cidade de São Paulo, a InduTech Store começou como uma pequena distribuidora de componentes elétricos industriais. Ao longo dos anos, crescemos e nos consolidamos como uma das principais lojas especializadas em automação industrial e ferramentas profissionais do Brasil.</p>
          <p class="mt-md">Hoje, contamos com um portfólio de mais de 2.000 produtos das melhores marcas mundiais como Siemens, WEG, Allen-Bradley, Schneider Electric, Fluke, Sick e muitas outras. Nossa equipe é formada por engenheiros eletricistas e técnicos especializados que oferecem suporte técnico qualificado.</p>
          <p class="mt-md">Nosso compromisso é sempre entregar o produto certo, no tempo certo, com o suporte que você precisa para manter sua produção funcionando.</p>
          <a routerLink="/contato" class="btn btn-primary btn-lg mt-xl">Falar com Nossa Equipe →</a>
        </div>
        <div class="story-visual">
          <div class="story-img">🏭</div>
          <div class="story-badges">
            <div class="story-badge"><span>ISO 9001</span>Certificado</div>
            <div class="story-badge"><span>15 anos</span>de Mercado</div>
            <div class="story-badge"><span>4.9⭐</span>Avaliação Média</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- BRANDS -->
  <section class="section">
    <div class="container">
      <div class="section-header">
        <h2>Marcas Parceiras</h2>
        <p>Trabalhamos com as maiores e mais confiáveis marcas do setor industrial</p>
      </div>
      <div class="brands-grid">
        <div class="brand-card" *ngFor="let b of brands">
          <span class="brand-card__name">{{ b.name }}</span>
          <span class="brand-card__country text-muted text-sm">{{ b.country }}</span>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="about-cta">
    <div class="container text-center">
      <h2>Pronto para modernizar sua produção?</h2>
      <p>Explore nosso catálogo completo ou fale com um especialista.</p>
      <div class="flex-center mt-xl" style="gap:16px; flex-wrap:wrap">
        <a routerLink="/catalogo" class="btn btn-accent btn-lg">Ver Catálogo →</a>
        <a routerLink="/contato" class="btn btn-outline-white btn-lg">Solicitar Orçamento</a>
      </div>
    </div>
  </section>
</div>
  `,
  styles: [`
    .about-page {}
    .about-hero { background: linear-gradient(135deg, var(--primary-dark) 0%, var(--gray-800) 100%); padding: 80px 0; &__label { display: inline-block; padding: 4px 14px; background: rgba(245,166,35,.2); color: var(--accent); border-radius: var(--radius-full); font-size: .8rem; font-weight: 700; text-transform: uppercase; letter-spacing: .1em; border: 1px solid rgba(245,166,35,.3); margin-bottom: 16px; } h1 { color: #fff; margin-bottom: 16px; } &__content p { color: rgba(255,255,255,.75); font-size: 1.1rem; max-width: 600px; line-height: 1.7; } }
    .numbers-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-lg); text-align: center; @media (max-width: 640px) { grid-template-columns: repeat(2, 1fr); } }
    .number-card { padding: var(--space-lg); &__value { display: block; font-family: var(--font-display); font-size: 2.5rem; font-weight: 900; color: var(--primary); } &__label { font-size: .875rem; color: var(--text-muted); } }
    .mission-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-lg); @media (max-width: 768px) { grid-template-columns: 1fr; } }
    .mission-card { text-align: center; padding: var(--space-xl); background: var(--surface); border-radius: var(--radius-xl); box-shadow: var(--shadow-sm); &__icon { font-size: 2.5rem; display: block; margin-bottom: var(--space-md); } h3 { margin-bottom: 10px; } p { color: var(--text-muted); font-size: .9rem; line-height: 1.7; } }
    .story-layout { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-2xl); align-items: center; @media (max-width: 768px) { grid-template-columns: 1fr; } p { color: var(--text-secondary); line-height: 1.8; } }
    .story-visual { display: flex; flex-direction: column; gap: var(--space-lg); }
    .story-img { width: 100%; aspect-ratio: 4/3; background: linear-gradient(135deg, var(--gray-100), var(--gray-200)); border-radius: var(--radius-xl); display: flex; align-items: center; justify-content: center; font-size: 8rem; }
    .story-badges { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
    .story-badge { background: var(--surface); border-radius: var(--radius-lg); padding: 14px; text-align: center; box-shadow: var(--shadow-sm); span { display: block; font-family: var(--font-display); font-size: 1.1rem; font-weight: 800; color: var(--primary); margin-bottom: 4px; } font-size: .78rem; color: var(--text-muted); }
    .brands-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 16px; }
    .brand-card { background: var(--surface); border-radius: var(--radius-lg); padding: 20px; text-align: center; box-shadow: var(--shadow-sm); border: 1.5px solid var(--gray-200); transition: all var(--transition-base); display: flex; flex-direction: column; gap: 4px; &:hover { border-color: var(--primary); transform: translateY(-2px); } &__name { font-family: var(--font-display); font-weight: 800; font-size: 1rem; } }
    .about-cta { background: linear-gradient(135deg, var(--primary-dark), var(--primary)); padding: 80px 0; h2 { color: #fff; margin-bottom: 12px; } p { color: rgba(255,255,255,.75); font-size: 1.05rem; } }
  `]
})
export class AboutComponent {
  numbers = [
    { value: '+2.000', label: 'Produtos em catálogo' },
    { value: '+500', label: 'Clientes ativos' },
    { value: '15 anos', label: 'De experiência' },
    { value: '4.9 ⭐', label: 'Avaliação média' },
  ];
  mission = [
    { icon: '🎯', title: 'Missão', text: 'Fornecer soluções de automação industrial de alta qualidade, contribuindo para a produtividade e competitividade da indústria brasileira.' },
    { icon: '👁', title: 'Visão', text: 'Ser a principal referência em soluções de automação industrial no Brasil, reconhecida pela excelência técnica e compromisso com o cliente.' },
    { icon: '💎', title: 'Valores', text: 'Qualidade, honestidade, inovação e suporte técnico especializado são os pilares que norteiam todas as nossas decisões.' },
  ];
  brands = [
    { name: 'Siemens', country: '🇩🇪 Alemanha' },
    { name: 'WEG', country: '🇧🇷 Brasil' },
    { name: 'Allen-Bradley', country: '🇺🇸 EUA' },
    { name: 'Schneider', country: '🇫🇷 França' },
    { name: 'Fluke', country: '🇺🇸 EUA' },
    { name: 'Sick', country: '🇩🇪 Alemanha' },
    { name: 'Balluff', country: '🇩🇪 Alemanha' },
    { name: 'Gedore', country: '🇩🇪 Alemanha' },
    { name: 'Stanley', country: '🇺🇸 EUA' },
    { name: 'Furukawa', country: '🇧🇷 Brasil' },
    { name: 'ABB', country: '🇨🇭 Suíça' },
    { name: 'Phoenix Contact', country: '🇩🇪 Alemanha' },
  ];
}
