import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../core/services/cart.service';
import { AuthService } from '../../core/services/auth.service';
import { OrderService } from '../../core/services/order.service';
import { ToastService } from '../../core/services/toast.service';
import { Address, PaymentMethod, ShippingOption } from '../../core/models';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.scss',
})
export class CheckoutComponent implements OnInit {
  private cart   = inject(CartService);
  private auth   = inject(AuthService);
  private orders = inject(OrderService);
  private toast  = inject(ToastService);
  private router = inject(Router);

  items    = this.cart.items;
  subtotal = this.cart.subtotal;
  total    = this.cart.total;

  step = signal<1|2|3>(1);
  loading = signal(false);
  orderCreated = signal<string | null>(null);

  address: Address = {
    id: 'addr_new', label: 'Entrega', street: '', number: '', complement: '',
    neighborhood: '', city: '', state: '', zipCode: '', isDefault: false,
  };

  selectedShipping = signal<ShippingOption | null>(null);
  shippingOptions: ShippingOption[] = [
    { carrier: 'Correios', service: 'PAC', price: 0, days: 7 },
    { carrier: 'Correios', service: 'SEDEX', price: 28.90, days: 3 },
    { carrier: 'Transportadora', service: 'Express', price: 45.00, days: 1 },
  ];

  paymentMethod = signal<PaymentMethod>('pix');
  card = { number: '', name: '', expiry: '', cvv: '', installments: 1 };
  cpf = '';

  readonly installmentOptions = [1,2,3,6,12];

  ngOnInit(): void {
    if (!this.items().length) this.router.navigate(['/carrinho']);
    if (this.subtotal() >= 500) {
      this.shippingOptions[0].price = 0; // PAC grátis acima de 500
    } else {
      this.shippingOptions[0].price = 18.90;
    }
    this.selectedShipping.set(this.shippingOptions[0]);
  }

  get orderTotal(): number {
    return this.subtotal() + (this.selectedShipping()?.price ?? 0);
  }

  nextStep(): void {
    if (this.step() === 1 && !this.validateAddress()) return;
    this.step.update(s => Math.min(s + 1, 3) as 1|2|3);
  }
  prevStep(): void { this.step.update(s => Math.max(s - 1, 1) as 1|2|3); }

  validateAddress(): boolean {
    if (!this.address.street || !this.address.number || !this.address.city ||
        !this.address.state || !this.address.zipCode) {
      this.toast.error('Preencha todos os campos obrigatórios do endereço');
      return false;
    }
    return true;
  }

  async placeOrder(): Promise<void> {
    if (this.loading()) return;
    this.loading.set(true);
    try {
      const order = await this.orders.createOrder({
        userId: this.auth.user()!.id,
        address: this.address,
        shipping: this.selectedShipping()!,
        paymentMethod: this.paymentMethod(),
        installments: this.card.installments,
      });
      this.orderCreated.set(order.id);
      this.step.set(3);
      this.toast.success('Pedido realizado com sucesso! 🎉');
    } catch (e) {
      this.toast.error('Erro ao processar pedido. Tente novamente.');
    } finally {
      this.loading.set(false);
    }
  }

  fmt(v: number) { return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
  fmtInstallment(total: number, n: number) { return this.fmt(total / n); }
}
