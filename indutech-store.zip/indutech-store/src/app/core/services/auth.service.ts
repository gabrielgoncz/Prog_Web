// =====================================================
// AUTH SERVICE
// Autenticação simulada com localStorage
// =====================================================
import { Injectable, signal, computed } from '@angular/core';
import { User, LoginCredentials, RegisterData } from '../models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly STORAGE_KEY = 'indutech_user';
  private readonly USERS_KEY   = 'indutech_users';

  private _user = signal<User | null>(this.loadUser());
  readonly user     = this._user.asReadonly();
  readonly isLoggedIn = computed(() => !!this._user());
  readonly isAdmin    = computed(() => this._user()?.role === 'admin');

  constructor() { this.seedAdminUser(); }

  /** Login simulado */
  login(credentials: LoginCredentials): Promise<User> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const users = this.getUsers();
        const found = users.find(
          u => u.email === credentials.email
        );
        if (!found) { reject(new Error('Usuário não encontrado')); return; }
        // Senha padrão demo: "senha123"
        const storedPwd = (found as any)._password;
        if (storedPwd !== credentials.password) { reject(new Error('Senha incorreta')); return; }
        this._user.set(found);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(found));
        resolve(found);
      }, 600);
    });
  }

  /** Cadastro simulado */
  register(data: RegisterData): Promise<User> {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const users = this.getUsers();
        if (users.some(u => u.email === data.email)) {
          reject(new Error('E-mail já cadastrado')); return;
        }
        const newUser: User = {
          id: `u_${Date.now()}`,
          name: data.name,
          email: data.email,
          phone: data.phone,
          cpf: data.cpf,
          addresses: [],
          role: 'customer',
          createdAt: new Date(),
          favorites: [],
        };
        const userWithPwd = { ...newUser, _password: data.password };
        localStorage.setItem(this.USERS_KEY, JSON.stringify([...users, userWithPwd]));
        this._user.set(newUser);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(newUser));
        resolve(newUser);
      }, 600);
    });
  }

  logout(): void {
    this._user.set(null);
    localStorage.removeItem(this.STORAGE_KEY);
  }

  toggleFavorite(productId: string): void {
    const user = this._user();
    if (!user) return;
    const favs = user.favorites.includes(productId)
      ? user.favorites.filter(id => id !== productId)
      : [...user.favorites, productId];
    const updated = { ...user, favorites: favs };
    this._user.set(updated);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updated));
    this.updateUserInList(updated);
  }

  isFavorite(productId: string): boolean {
    return this._user()?.favorites.includes(productId) ?? false;
  }

  private updateUserInList(user: User): void {
    const users = this.getUsers();
    const updated = users.map(u => u.id === user.id ? { ...u, ...user } : u);
    localStorage.setItem(this.USERS_KEY, JSON.stringify(updated));
  }

  private getUsers(): any[] {
    try {
      const raw = localStorage.getItem(this.USERS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  }

  private loadUser(): User | null {
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }

  private seedAdminUser(): void {
    const users = this.getUsers();
    if (!users.some(u => u.email === 'admin@indutech.com.br')) {
      const admin: any = {
        id: 'admin_001', name: 'Administrador', email: 'admin@indutech.com.br',
        role: 'admin', addresses: [], favorites: [], createdAt: new Date(),
        _password: 'admin123',
      };
      localStorage.setItem(this.USERS_KEY, JSON.stringify([...users, admin]));
    }
    if (!users.some(u => u.email === 'demo@indutech.com.br')) {
      const demo: any = {
        id: 'demo_001', name: 'João Silva', email: 'demo@indutech.com.br',
        phone: '(11) 98765-4321', cpf: '123.456.789-00',
        role: 'customer', addresses: [], favorites: [], createdAt: new Date(),
        _password: 'senha123',
      };
      const fresh = this.getUsers();
      localStorage.setItem(this.USERS_KEY, JSON.stringify([...fresh, demo]));
    }
  }
}
