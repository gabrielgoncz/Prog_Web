import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-logo">
      <svg width="40" height="40" viewBox="0 0 32 32" fill="none">
        <rect width="32" height="32" rx="6" fill="#0a4f8c"/>
        <path d="M8 10h16M8 16h10M8 22h13" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
        <circle cx="26" cy="22" r="3" fill="#f5a623"/>
      </svg>
      <span>InduTech Store</span>
    </div>

    <h1>Criar Conta</h1>
    <p class="auth-subtitle">Junte-se a mais de 500 clientes industriais</p>

    <form (submit)="onSubmit(); $event.preventDefault()">
      <div class="form-group">
        <label class="form-label">Nome completo *</label>
        <input class="form-control" type="text" [(ngModel)]="data.name" name="name" placeholder="Seu nome completo" required/>
      </div>
      <div class="form-group">
        <label class="form-label">E-mail *</label>
        <input class="form-control" type="email" [(ngModel)]="data.email" name="email" placeholder="seu@email.com" required/>
      </div>
      <div class="form-group">
        <label class="form-label">Telefone</label>
        <input class="form-control" type="tel" [(ngModel)]="data.phone" name="phone" placeholder="(11) 99999-9999"/>
      </div>
      <div class="form-group">
        <label class="form-label">CPF</label>
        <input class="form-control" type="text" [(ngModel)]="data.cpf" name="cpf" placeholder="000.000.000-00"/>
      </div>
      <div class="form-group">
        <label class="form-label">Senha *</label>
        <input class="form-control" type="password" [(ngModel)]="data.password" name="password" placeholder="Mínimo 6 caracteres" required/>
      </div>
      <div class="form-group">
        <label class="form-label">Confirmar Senha *</label>
        <input class="form-control" type="password" [(ngModel)]="confirmPassword" name="confirmPassword" placeholder="Repita a senha" required/>
      </div>

      <div class="form-error" *ngIf="error()">{{ error() }}</div>

      <button class="btn btn-primary btn-full btn-lg" type="submit" [disabled]="loading()">
        {{ loading() ? 'Criando conta...' : 'Criar Conta Grátis' }}
      </button>
    </form>

    <p class="terms text-sm text-muted text-center mt-md">
      Ao criar uma conta você concorda com nossos <a href="#">Termos de Uso</a> e <a href="#">Política de Privacidade</a>.
    </p>

    <div class="divider"><span>já tem conta?</span></div>
    <a routerLink="/login" class="btn btn-outline btn-full">Entrar na minha conta</a>
  </div>
</div>
  `,
  styles: [`
    .auth-page { min-height: calc(100vh - 180px); display: flex; align-items: center; justify-content: center; padding: var(--space-xl) var(--space-md); }
    .auth-card { width: 100%; max-width: 460px; background: var(--surface); border-radius: var(--radius-xl); padding: var(--space-2xl); box-shadow: var(--shadow-xl); }
    .auth-logo { display: flex; align-items: center; gap: 10px; margin-bottom: var(--space-xl); font-family: var(--font-display); font-size: 1.2rem; font-weight: 800; color: var(--primary); }
    h1 { font-size: 1.75rem; margin-bottom: 6px; }
    .auth-subtitle { color: var(--text-muted); margin-bottom: var(--space-xl); }
    .form-error { color: var(--danger); font-size: .875rem; margin-bottom: var(--space-md); }
    .terms a { color: var(--primary); }
  `]
})
export class RegisterComponent {
  private auth   = inject(AuthService);
  private toast  = inject(ToastService);
  private router = inject(Router);

  data = { name: '', email: '', password: '', phone: '', cpf: '' };
  confirmPassword = '';
  loading = signal(false);
  error   = signal('');

  async onSubmit(): Promise<void> {
    this.error.set('');
    if (!this.data.name || !this.data.email || !this.data.password) { this.error.set('Preencha todos os campos obrigatórios'); return; }
    if (this.data.password !== this.confirmPassword) { this.error.set('As senhas não coincidem'); return; }
    if (this.data.password.length < 6) { this.error.set('A senha deve ter ao menos 6 caracteres'); return; }
    this.loading.set(true);
    try {
      await this.auth.register(this.data);
      this.toast.success('Conta criada com sucesso! 🎉');
      this.router.navigate(['/']);
    } catch (e: any) {
      this.error.set(e.message || 'Erro ao criar conta.');
    } finally {
      this.loading.set(false);
    }
  }
}
