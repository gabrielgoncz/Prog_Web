import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { OrderService } from '../../core/services/order.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  template: `
<div class="dashboard-page">
  <div class="container">
    <div class="dashboard-layout">
      <!-- SIDEBAR -->
      <aside class="dashboard-sidebar">
        <div class="user-avatar">
          <div class="avatar-circle">{{ initials() }}</div>
          <div>
            <strong>{{ user()?.name }}</strong>
            <span class="text-muted text-sm">{{ user()?.email }}</span>
            <span class="badge badge-primary text-sm" *ngIf="user()?.role === 'admin'">Admin</span>
          </div>
        </div>
        <nav class="dashboard-nav">
          <a routerLink="/minha-conta" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}" class="dashboard-nav__item">👤 Meu Perfil</a>
          <a routerLink="/minha-conta/pedidos" routerLinkActive="active" class="dashboard-nav__item">📦 Meus Pedidos</a>
          <a routerLink="/minha-conta/favoritos" routerLinkActive="active" class="dashboard-nav__item">❤️ Favoritos</a>
          <a *ngIf="user()?.role === 'admin'" routerLink="/admin" class="dashboard-nav__item">⚙️ Administração</a>
        </nav>
      </aside>

      <!-- MAIN -->
      <main class="dashboard-main">
        <h2>Bem-vindo, {{ user()?.name?.split(' ')[0] }}! 👋</h2>

        <div class="dashboard-stats">
          <div class="stat-card">
            <span class="stat-card__icon">📦</span>
            <div>
              <strong>{{ orders().length }}</strong>
              <span>Pedidos</span>
            </div>
          </div>
          <div class="stat-card">
            <span class="stat-card__icon">❤️</span>
            <div>
              <strong>{{ user()?.favorites?.length ?? 0 }}</strong>
              <span>Favoritos</span>
            </div>
          </div>
          <div class="stat-card">
            <span class="stat-card__icon">📍</span>
            <div>
              <strong>{{ user()?.addresses?.length ?? 0 }}</strong>
              <span>Endereços</span>
            </div>
          </div>
        </div>

        <div class="dashboard-recent" *ngIf="orders().length">
          <h3>Pedidos Recentes</h3>
          <div class="order-card" *ngFor="let order of orders().slice(0,3)">
            <div class="order-card__header">
              <span class="order-id">{{ order.id }}</span>
              <span class="order-status status-{{ order.status }}">{{ statusLabel(order.status) }}</span>
            </div>
            <div class="order-card__body">
              <span class="text-muted text-sm">{{ order.items.length }} {{ order.items.length === 1 ? 'item' : 'itens' }}</span>
              <span class="price price-sm">{{ fmt(order.total) }}</span>
            </div>
          </div>
          <a routerLink="/minha-conta/pedidos" class="btn btn-ghost btn-sm mt-md">Ver todos os pedidos →</a>
        </div>

        <div class="empty-state" *ngIf="!orders().length">
          <div class="empty-icon">📦</div>
          <h3>Nenhum pedido ainda</h3>
          <p>Explore nosso catálogo e faça seu primeiro pedido!</p>
          <a routerLink="/catalogo" class="btn btn-primary">Ver Produtos</a>
        </div>
      </main>
    </div>
  </div>
</div>
  `,
  styles: [`
    .dashboard-page { padding: var(--space-xl) 0; }
    .dashboard-layout { display: grid; grid-template-columns: 260px 1fr; gap: var(--space-xl); align-items: start; @media (max-width: 768px) { grid-template-columns: 1fr; } }
    .dashboard-sidebar { background: var(--surface); border-radius: var(--radius-lg); padding: var(--space-lg); box-shadow: var(--shadow-sm); position: sticky; top: calc(var(--header-height) + 100px); }
    .user-avatar { display: flex; align-items: center; gap: 12px; margin-bottom: var(--space-lg); padding-bottom: var(--space-lg); border-bottom: 1px solid var(--gray-100); }
    .avatar-circle { width: 52px; height: 52px; border-radius: 50%; background: var(--primary); color: #fff; font-family: var(--font-display); font-size: 1.25rem; font-weight: 800; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .dashboard-nav { display: flex; flex-direction: column; gap: 4px; }
    .dashboard-nav__item { padding: 10px 12px; border-radius: var(--radius-md); font-size: .9rem; font-weight: 600; color: var(--text-secondary); text-decoration: none; transition: all var(--transition-fast); &:hover { background: var(--gray-50); color: var(--primary); } &.active { background: var(--primary); color: #fff; } }
    .dashboard-main h2 { margin-bottom: var(--space-lg); }
    .dashboard-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-md); margin-bottom: var(--space-xl); }
    .stat-card { background: var(--surface); border-radius: var(--radius-lg); padding: var(--space-lg); box-shadow: var(--shadow-sm); display: flex; align-items: center; gap: 14px; &__icon { font-size: 2rem; } strong { display: block; font-size: 1.75rem; font-family: var(--font-display); font-weight: 800; color: var(--primary); } span { font-size: .8rem; color: var(--text-muted); } }
    .dashboard-recent h3 { margin-bottom: var(--space-md); }
    .order-card { background: var(--surface); border-radius: var(--radius-md); padding: var(--space-md); margin-bottom: 8px; box-shadow: var(--shadow-sm); &__header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; } &__body { display: flex; justify-content: space-between; align-items: center; } }
    .order-id { font-family: var(--font-display); font-weight: 700; font-size: .9rem; }
    .order-status { padding: 3px 10px; border-radius: var(--radius-full); font-size: .75rem; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; }
    .status-confirmed   { background: rgba(10,79,140,.1); color: var(--primary); }
    .status-processing  { background: rgba(245,166,35,.1); color: var(--accent-dark); }
    .status-shipped     { background: rgba(46,204,113,.1); color: #1a9e55; }
    .status-delivered   { background: rgba(46,204,113,.15); color: #1a9e55; }
    .status-cancelled   { background: rgba(229,62,62,.1); color: var(--danger); }
    .status-pending     { background: var(--gray-100); color: var(--text-muted); }
    @media (max-width: 480px) { .dashboard-stats { grid-template-columns: 1fr; } }
  `]
})
export class DashboardComponent {
  private auth   = inject(AuthService);
  private orderSvc = inject(OrderService);
  user   = this.auth.user;
  orders = () => this.orderSvc.getOrdersByUser(this.user()?.id ?? '');
  initials = () => (this.user()?.name ?? 'U').split(' ').map(n => n[0]).join('').substring(0,2).toUpperCase();
  fmt(v: number) { return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); }
  statusLabel(s: string) { const m: any = { pending:'Pendente', confirmed:'Confirmado', processing:'Em Processo', shipped:'Enviado', delivered:'Entregue', cancelled:'Cancelado' }; return m[s] ?? s; }
}
