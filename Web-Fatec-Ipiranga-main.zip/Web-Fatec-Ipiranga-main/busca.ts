import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { Produto } from '../model/produto';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { ItemCesta } from '../model/item-cesta';

@Component({
  selector: 'app-busca',
  imports: [CommonModule],
  templateUrl: './busca.html',
  styleUrl: './busca.css',
})
export class Busca {
  mensagem: string = "";
  lista: Produto[] = [];

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      let termo = localStorage.getItem("termoBusca");
      let produtosJson = localStorage.getItem("produtos");
      let todosProdutos: Produto[] = [];

      if (produtosJson != null) {
        todosProdutos = JSON.parse(produtosJson);
      } else {
        todosProdutos = this.getProdutosPadrao();
        localStorage.setItem("produtos", JSON.stringify(todosProdutos));
      }

      if (termo && termo.trim() != "") {
        let termoLower = termo.toLowerCase();
        this.lista = todosProdutos.filter(produto =>
          produto.nome.toLowerCase().includes(termoLower) ||
          produto.keywords.toLowerCase().includes(termoLower)
        );

        if (this.lista.length == 0) {
          this.mensagem = "Nenhum produto encontrado para: " + termo;
        }

        setTimeout(() => {
          localStorage.removeItem("termoBusca");
        }, 100);
      }
      else {  
        window.location.href = "vitrine";
      }
    }
  }

  getProdutosPadrao(): Produto[] {
    return [
      { codigo: 1, nome: "Ração Premium para Gatos", descritivo: "Ração super premium com sabor de frango", valor: 89.90, promo: 69.90, quantidade: 50, keywords: "ração comida frango premium", imagem: "racao-premium.png" },
      { codigo: 2, nome: "Arranhador 3 níveis", descritivo: "Arranhador completo com 3 níveis", valor: 149.90, promo: 119.90, quantidade: 20, keywords: "arranhador brinquedo diversão", imagem: "arranhador-tres-andares.png" },
      { codigo: 3, nome: "Brinquedo Varinha com Penas", descritivo: "Varinha interativa com penas coloridas", valor: 29.90, promo: 19.90, quantidade: 100, keywords: "brinquedo varinha pena interativo", imagem: "varinha-brinquedo.png" },
      { codigo: 4, nome: "Cama Redonda para Gatos", descritivo: "Cama macia e aconchegante", valor: 79.90, promo: 59.90, quantidade: 35, keywords: "cama descanso conforto dormir", imagem: "cama-redonda.png" },
      { codigo: 5, nome: "Areia Higiênica Premium", descritivo: "Areia de sílica com alta absorção", valor: 39.90, promo: 29.90, quantidade: 80, keywords: "areia higiene caixa sanitário", imagem: "areia-higienica.png" },
      { codigo: 6, nome: "Sachê Úmido Sabor Salmão", descritivo: "Sachê úmido sabor salmão", valor: 4.90, promo: 3.50, quantidade: 200, keywords: "sachê úmido salmão comida", imagem: "sache-umido.png" },
      { codigo: 7, nome: "Coleira com Guizo", descritivo: "Coleira ajustável com guizo", valor: 24.90, promo: 24.90, quantidade: 60, keywords: "coleira acessório guizo segurança", imagem: "coleira-com-guizo.png" },
      { codigo: 8, nome: "Escova Removedora de Pelos", descritivo: "Escova profissional para remover pelos", valor: 34.90, promo: 34.90, quantidade: 45, keywords: "escova pelos higiene cuidados", imagem: "escova-removedora.png" },
      { codigo: 9, nome: "Fonte de Água com Filtro", descritivo: "Fonte de água com filtro", valor: 129.90, promo: 99.90, quantidade: 25, keywords: "fonte água filtro hidratação", imagem: "filtro.png" },
      { codigo: 10, nome: "Caixa de Transporte", descritivo: "Caixa de transporte resistente", valor: 89.90, promo: 74.90, quantidade: 30, keywords: "caixa transporte viagem segurança", imagem: "caixa-transporte.png" },
      { codigo: 11, nome: "Snacks Sabor Frango", descritivo: "Petiscos crocantes sabor frango", valor: 19.90, promo: 14.90, quantidade: 150, keywords: "snack petisco frango premio", imagem: "snack.png" },
      { codigo: 12, nome: "Ratinho de Brinquedo", descritivo: "Brinquedo de pelúcia formato ratinho", valor: 15.90, promo: 9.90, quantidade: 90, keywords: "rato brinquedo catnip diversão", imagem: "rato-brinquedo.png" }
    ];
  }

  redirecionar(obj: Produto) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem("ProdutoSelecionado", JSON.stringify(obj));
      window.location.href = "detalhe";
    }
  }

  adicionarItemCesta(obj: Produto) {
    if (isPlatformBrowser(this.platformId)) {
      let json = localStorage.getItem("cesta");
      let lista: ItemCesta[] = [];

      let item: ItemCesta = new ItemCesta();
      
      item.produto = obj;
      item.quantidade = 1;
      let valorProduto = obj.promo < obj.valor ? obj.promo : obj.valor;
      item.valor = valorProduto;

      if (json != null) {
        lista = JSON.parse(json);
      }
      lista.push(item);
      localStorage.setItem("cesta", JSON.stringify(lista));
      window.location.href = "cesta";
    }
  }
}