import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-toast-container',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="toast-container">
      <div
        *ngFor="let toast of toastService.toasts()"
        class="toast toast-{{ toast.type }}"
        (click)="toastService.dismiss(toast.id)"
      >
        <span class="toast-icon">{{ toast.icon }}</span>
        <span>{{ toast.message }}</span>
      </div>
    </div>
  `,
  styles: [`
    .toast-container {
      position: fixed; bottom: 24px; right: 24px;
      z-index: 9999; display: flex; flex-direction: column; gap: 8px;
    }
    .toast {
      padding: 12px 20px; border-radius: var(--radius-md);
      background: var(--gray-800); color: #fff;
      font-size: .9rem; font-weight: 500;
      box-shadow: var(--shadow-xl);
      animation: fadeIn .3s ease;
      display: flex; align-items: center; gap: 10px;
      min-width: 260px; max-width: 380px;
      cursor: pointer;
    }
    .toast-success { border-left: 4px solid var(--success); }
    .toast-error   { border-left: 4px solid var(--danger); }
    .toast-info    { border-left: 4px solid var(--primary); }
    .toast-warning { border-left: 4px solid var(--accent); }
    .toast-icon { font-size: 1.1rem; flex-shrink: 0; }
  `]
})
export class ToastContainerComponent {
  toastService = inject(ToastService);
}
