import { Component, inject, signal, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MockDataService } from '../../core/services/mock-data.service';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { Product, Category } from '../../core/models';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, CommonModule, ProductCardComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
})
export class HomeComponent implements OnInit {
  private mock = inject(MockDataService);

  featuredProducts = signal<Product[]>([]);
  onSaleProducts   = signal<Product[]>([]);
  newProducts      = signal<Product[]>([]);
  categories       = signal<Category[]>([]);
  currentSlide     = signal(0);

  readonly slides = [
    {
      title: 'CLPs e Automação Industrial',
      subtitle: 'Siemens, Allen-Bradley, Schneider e mais',
      cta: 'Ver CLPs',
      link: '/catalogo/clps-controladores',
      badge: 'Linha completa',
      color: 'from-blue to-dark',
      emoji: '🖥️',
    },
    {
      title: 'Até 15% OFF em Inversores',
      subtitle: 'WEG, Siemens, ABB com entrega imediata',
      cta: 'Ver Promoções',
      link: '/catalogo/inversores-frequencia',
      badge: 'Promoção especial',
      color: 'from-accent to-dark',
      emoji: '⚡',
    },
    {
      title: 'Ferramentas Profissionais',
      subtitle: 'Gedore, Stanley, Fluke para indústria',
      cta: 'Explorar Ferramentas',
      link: '/catalogo/ferramentas-manuais',
      badge: 'Novidades',
      color: 'from-dark to-blue',
      emoji: '🔧',
    },
  ];

  readonly benefits = [
    { icon: '🚚', title: 'Frete Grátis', desc: 'Acima de R$ 500' },
    { icon: '🔒', title: 'Pagamento Seguro', desc: 'SSL 256-bit' },
    { icon: '↩️', title: 'Devolução', desc: '30 dias garantidos' },
    { icon: '🏭', title: 'Suporte Técnico', desc: 'Especialistas disponíveis' },
    { icon: '💳', title: 'Parcelamento', desc: 'Até 12x sem juros' },
    { icon: '📦', title: 'Estoque Próprio', desc: 'Entrega imediata' },
  ];

  readonly brands = ['Siemens', 'WEG', 'Allen-Bradley', 'Schneider', 'Fluke', 'Sick', 'Balluff', 'Gedore', 'Stanley', 'Furukawa'];

  ngOnInit(): void {
    this.featuredProducts.set(this.mock.getFeaturedProducts());
    this.onSaleProducts.set(this.mock.getOnSaleProducts());
    this.newProducts.set(this.mock.getNewProducts());
    this.categories.set(this.mock.getCategories());
    this.startSlider();
  }

  private startSlider(): void {
    setInterval(() => {
      this.currentSlide.update(s => (s + 1) % this.slides.length);
    }, 5000);
  }

  goToSlide(i: number): void { this.currentSlide.set(i); }
}
