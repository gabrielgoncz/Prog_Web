import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
<div class="admin-page">
  <div class="container">
    <div class="admin-header">
      <h1>⚙️ Painel Administrativo</h1>
      <p class="text-muted">Gerencie produtos, pedidos e clientes da InduTech Store</p>
    </div>
    <div class="admin-cards">
      <a routerLink="/admin/produtos" class="admin-card">
        <span class="admin-card__icon">📦</span>
        <h3>Produtos</h3>
        <p>Cadastrar, editar e remover produtos do catálogo</p>
        <span class="btn btn-primary btn-sm mt-md">Gerenciar →</span>
      </a>
      <div class="admin-card coming-soon">
        <span class="admin-card__icon">🛒</span>
        <h3>Pedidos</h3>
        <p>Visualizar e atualizar status dos pedidos</p>
        <span class="badge badge-primary mt-md">Em breve</span>
      </div>
      <div class="admin-card coming-soon">
        <span class="admin-card__icon">👥</span>
        <h3>Clientes</h3>
        <p>Gerenciar base de clientes e permissões</p>
        <span class="badge badge-primary mt-md">Em breve</span>
      </div>
      <div class="admin-card coming-soon">
        <span class="admin-card__icon">📊</span>
        <h3>Relatórios</h3>
        <p>Vendas, produtos mais vendidos e métricas</p>
        <span class="badge badge-primary mt-md">Em breve</span>
      </div>
    </div>
  </div>
</div>
  `,
  styles: [`
    .admin-page { padding: var(--space-2xl) 0; }
    .admin-header { margin-bottom: var(--space-2xl); }
    .admin-header h1 { margin-bottom: 8px; }
    .admin-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: var(--space-lg); }
    .admin-card { background: var(--surface); border-radius: var(--radius-xl); padding: var(--space-xl); box-shadow: var(--shadow-sm); text-decoration: none; display: flex; flex-direction: column; gap: 8px; transition: all var(--transition-base); border: 1.5px solid var(--gray-200); &:hover:not(.coming-soon) { box-shadow: var(--shadow-lg); transform: translateY(-4px); border-color: var(--primary); } &__icon { font-size: 2.5rem; } h3 { font-size: 1.1rem; } p { color: var(--text-muted); font-size: .875rem; flex: 1; } &.coming-soon { opacity: .7; cursor: default; } }
  `]
})
export class AdminComponent {}
