// =====================================================
// CART SERVICE
// Gerenciamento do carrinho com persistência localStorage
// =====================================================
import { Injectable, signal, computed } from '@angular/core';
import { Cart, CartItem, Product } from '../models';

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly STORAGE_KEY = 'indutech_cart';

  // Signal reativo com estado do carrinho
  private _items = signal<CartItem[]>(this.loadFromStorage());

  // Computeds derivados do estado
  readonly items = this._items.asReadonly();

  readonly itemCount = computed(() =>
    this._items().reduce((sum, item) => sum + item.quantity, 0)
  );

  readonly subtotal = computed(() =>
    this._items().reduce((sum, item) => sum + item.product.price * item.quantity, 0)
  );

  readonly shipping = computed(() => {
    const sub = this.subtotal();
    if (sub === 0) return 0;
    if (sub >= 500) return 0;   // Frete grátis acima de R$500
    return 35.90;
  });

  readonly total = computed(() => this.subtotal() + this.shipping());

  readonly cart = computed<Cart>(() => ({
    items: this._items(),
    subtotal: this.subtotal(),
    shipping: this.shipping(),
    discount: 0,
    total: this.total(),
  }));

  /** Adiciona produto ou incrementa quantidade */
  addItem(product: Product, quantity = 1): void {
    this._items.update(items => {
      const existing = items.find(i => i.product.id === product.id);
      if (existing) {
        return items.map(i =>
          i.product.id === product.id
            ? { ...i, quantity: Math.min(i.quantity + quantity, product.stock) }
            : i
        );
      }
      return [...items, { product, quantity: Math.min(quantity, product.stock) }];
    });
    this.saveToStorage();
  }

  /** Remove item do carrinho */
  removeItem(productId: string): void {
    this._items.update(items => items.filter(i => i.product.id !== productId));
    this.saveToStorage();
  }

  /** Atualiza quantidade de um item */
  updateQuantity(productId: string, quantity: number): void {
    if (quantity <= 0) { this.removeItem(productId); return; }
    this._items.update(items =>
      items.map(i =>
        i.product.id === productId
          ? { ...i, quantity: Math.min(quantity, i.product.stock) }
          : i
      )
    );
    this.saveToStorage();
  }

  /** Verifica se produto está no carrinho */
  isInCart(productId: string): boolean {
    return this._items().some(i => i.product.id === productId);
  }

  /** Limpa o carrinho */
  clear(): void {
    this._items.set([]);
    this.saveToStorage();
  }

  private saveToStorage(): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this._items()));
    } catch { /* ignore */ }
  }

  private loadFromStorage(): CartItem[] {
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  }
}
