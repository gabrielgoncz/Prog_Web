// =====================================================
// HEADER COMPONENT
// Barra de navegação principal com busca e carrinho
// =====================================================
import { Component, computed, signal, HostListener, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../../core/services/cart.service';
import { AuthService } from '../../../core/services/auth.service';
import { MockDataService } from '../../../core/services/mock-data.service';
import { Product } from '../../../core/models';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, CommonModule, FormsModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  private cart   = inject(CartService);
  private auth   = inject(AuthService);
  private mock   = inject(MockDataService);
  private router = inject(Router);

  cartCount    = this.cart.itemCount;
  isLoggedIn   = this.auth.isLoggedIn;
  isAdmin      = this.auth.isAdmin;
  user         = this.auth.user;
  categories   = this.mock.getCategories();

  searchQuery     = signal('');
  searchResults   = signal<Product[]>([]);
  showSearch      = signal(false);
  menuOpen        = signal(false);
  userMenuOpen    = signal(false);
  scrolled        = signal(false);

  @HostListener('window:scroll')
  onScroll() { this.scrolled.set(window.scrollY > 60); }

  @HostListener('document:click', ['$event'])
  onDocClick(e: MouseEvent) {
    const t = e.target as HTMLElement;
    if (!t.closest('.search-wrapper'))  this.showSearch.set(false);
    if (!t.closest('.user-menu-wrap'))  this.userMenuOpen.set(false);
  }

  onSearch(q: string): void {
    this.searchQuery.set(q);
    if (q.trim().length < 2) { this.searchResults.set([]); this.showSearch.set(false); return; }
    const results = this.mock.getProducts().filter(p =>
      p.name.toLowerCase().includes(q.toLowerCase()) ||
      p.brand.toLowerCase().includes(q.toLowerCase()) ||
      p.tags.some(t => t.toLowerCase().includes(q.toLowerCase()))
    ).slice(0, 6);
    this.searchResults.set(results);
    this.showSearch.set(true);
  }

  goToProduct(slug: string): void {
    this.showSearch.set(false);
    this.searchQuery.set('');
    this.router.navigate(['/produto', slug]);
  }

  submitSearch(): void {
    if (!this.searchQuery().trim()) return;
    this.showSearch.set(false);
    this.router.navigate(['/catalogo'], { queryParams: { q: this.searchQuery() } });
  }

  logout(): void {
    this.auth.logout();
    this.userMenuOpen.set(false);
    this.router.navigate(['/']);
  }

  formatPrice(p: number): string {
    return p.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
}
