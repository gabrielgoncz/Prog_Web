import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { Produto } from '../model/produto';
import { ItemCesta } from '../model/item-cesta';

@Component({
  selector: 'app-vitrine',
  imports: [CommonModule],
  templateUrl: './vitrine.html',
  styleUrl: './vitrine.css',
})
export class Vitrine {
  lista: Produto[] = [];

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit() {
    this.carregarProdutos();
  }

  carregarProdutos() {
    if (isPlatformBrowser(this.platformId)) {
      let produtosJson = localStorage.getItem("produtos");
      
      if (produtosJson != null) {
        this.lista = JSON.parse(produtosJson);
      } else {
        this.lista = this.getProdutosPadrao();
        localStorage.setItem("produtos", JSON.stringify(this.lista));
      }
    } else {
      this.lista = this.getProdutosPadrao();
    }
  }

  getProdutosPadrao(): Produto[] {
    return [
      { codigo: 1, nome: "Ração Premium para Gatos", descritivo: "Ração super premium", valor: 89.90, promo: 69.90, quantidade: 50, keywords: "ração", imagem: "racao-premium.png" },
      { codigo: 2, nome: "Arranhador 3 níveis", descritivo: "Arranhador completo", valor: 149.90, promo: 119.90, quantidade: 20, keywords: "arranhador", imagem: "arranhador-tres-andares.png" },
      { codigo: 3, nome: "Brinquedo Varinha com Penas", descritivo: "Varinha interativa", valor: 29.90, promo: 19.90, quantidade: 100, keywords: "brinquedo", imagem: "varinha-brinquedo.png" },
      { codigo: 4, nome: "Cama Redonda para Gatos", descritivo: "Cama macia", valor: 79.90, promo: 59.90, quantidade: 35, keywords: "cama", imagem: "cama-redonda.png" },
      { codigo: 5, nome: "Areia Higiênica Premium", descritivo: "Areia de sílica", valor: 39.90, promo: 29.90, quantidade: 80, keywords: "areia", imagem: "areia-higienica.png" },
      { codigo: 6, nome: "Sachê Úmido Sabor Salmão", descritivo: "Sachê saboroso", valor: 4.90, promo: 3.50, quantidade: 200, keywords: "sachê", imagem: "sache-umido.png" },
      { codigo: 7, nome: "Coleira com Guizo", descritivo: "Coleira ajustável", valor: 24.90, promo: 24.90, quantidade: 60, keywords: "coleira", imagem: "coleira-com-guizo.png" },
      { codigo: 8, nome: "Escova Removedora de Pelos", descritivo: "Escova profissional", valor: 34.90, promo: 34.90, quantidade: 45, keywords: "escova", imagem: "escova-removedora.png" },
      { codigo: 9, nome: "Fonte de Água com Filtro", descritivo: "Fonte com filtro", valor: 129.90, promo: 99.90, quantidade: 25, keywords: "fonte", imagem: "filtro.png" },
      { codigo: 10, nome: "Caixa de Transporte", descritivo: "Caixa resistente", valor: 89.90, promo: 74.90, quantidade: 30, keywords: "caixa", imagem: "caixa-transporte.png" },
      { codigo: 11, nome: "Snacks Sabor Frango", descritivo: "Petiscos crocantes", valor: 19.90, promo: 14.90, quantidade: 150, keywords: "snack", imagem: "snack.png" },
      { codigo: 12, nome: "Ratinho de Brinquedo", descritivo: "Brinquedo de pelúcia", valor: 15.90, promo: 9.90, quantidade: 90, keywords: "rato", imagem: "rato-brinquedo.png" }
    ];
  }

  redirecionar(obj: Produto) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem("ProdutoSelecionado", JSON.stringify(obj));
      window.location.href = "detalhe";
    }
  }

  adicionarItemCesta(obj: Produto) {
    if (isPlatformBrowser(this.platformId)) {
      let json = localStorage.getItem("cesta");
      let lista: ItemCesta[] = [];

      if (json != null) {
        lista = JSON.parse(json);
      }

      let itemExistente = lista.find(item => item.produto.codigo === obj.codigo);
      let valorProduto = obj.promo < obj.valor ? obj.promo : obj.valor;

      if (itemExistente) {
        itemExistente.quantidade++;
        itemExistente.valor = itemExistente.quantidade * valorProduto;
      } else {
        let item: ItemCesta = new ItemCesta();
        item.produto = obj;
        item.quantidade = 1;
        item.valor = valorProduto;
        lista.push(item);
      }

      localStorage.setItem("cesta", JSON.stringify(lista));
      window.location.href = "cesta";
    }
  }
}