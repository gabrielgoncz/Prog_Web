import { Injectable, signal } from '@angular/core';
import { Order, OrderStatus, CartItem, Address, ShippingOption, PaymentMethod } from '../models';
import { CartService } from './cart.service';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private readonly STORAGE_KEY = 'indutech_orders';
  private _orders = signal<Order[]>(this.loadOrders());
  readonly orders = this._orders.asReadonly();

  constructor(private cart: CartService) {}

  createOrder(params: {
    userId: string;
    address: Address;
    shipping: ShippingOption;
    paymentMethod: PaymentMethod;
    installments?: number;
  }): Promise<Order> {
    return new Promise(resolve => {
      setTimeout(() => {
        const order: Order = {
          id: `PED-${Date.now().toString().slice(-8)}`,
          userId: params.userId,
          items: [...this.cart.items()],
          status: 'confirmed',
          address: params.address,
          payment: {
            method: params.paymentMethod,
            status: 'approved',
            installments: params.installments,
            transactionId: `TXN-${Math.random().toString(36).slice(2).toUpperCase()}`,
          },
          subtotal: this.cart.subtotal(),
          shipping: params.shipping.price,
          discount: 0,
          total: this.cart.total() + params.shipping.price,
          tracking: undefined,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        this._orders.update(o => [order, ...o]);
        this.saveOrders();
        this.cart.clear();
        resolve(order);
      }, 1500);
    });
  }

  getOrdersByUser(userId: string): Order[] {
    return this._orders().filter(o => o.userId === userId);
  }

  updateStatus(orderId: string, status: OrderStatus): void {
    this._orders.update(orders =>
      orders.map(o => o.id === orderId ? { ...o, status, updatedAt: new Date() } : o)
    );
    this.saveOrders();
  }

  private saveOrders(): void {
    try { localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this._orders())); } catch {}
  }

  private loadOrders(): Order[] {
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  }
}
